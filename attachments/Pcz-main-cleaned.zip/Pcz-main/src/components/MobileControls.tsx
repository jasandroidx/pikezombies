import React, { useRef, useState, useEffect } from 'react';
import { RotateCcw, Flame, ChevronLeft, ChevronRight, FileText } from 'lucide-react';

interface MobileControlsProps {
  onMoveChange: (vec: { x: number; y: number }) => void;
  onAimChange: (vec: { x: number; y: number }) => void;
  onReload: () => void;
  onThrowMolotov: () => void;
  onPrevWeapon: () => void;
  onNextWeapon: () => void;
  onInteract?: () => void;
}

export const MobileControls: React.FC<MobileControlsProps> = ({
  onMoveChange,
  onAimChange,
  onReload,
  onThrowMolotov,
  onPrevWeapon,
  onNextWeapon,
  onInteract,
}) => {
  const [isTouchDevice, setIsTouchDevice] = useState(false);

  const moveStickRef = useRef<HTMLDivElement>(null);
  const aimStickRef = useRef<HTMLDivElement>(null);

  const [movePos, setMovePos] = useState({ x: 0, y: 0 });
  const [aimPos, setAimPos] = useState({ x: 0, y: 0 });

  useEffect(() => {
    // Detect touch device
    const checkTouch = () => {
      setIsTouchDevice('ontouchstart' in window || navigator.maxTouchPoints > 0);
    };
    checkTouch();
  }, []);

  if (!isTouchDevice) return null;

  const handleStickTouch = (
    e: React.TouchEvent,
    stickRef: React.RefObject<HTMLDivElement | null>,
    setPos: (pos: { x: number; y: number }) => void,
    onChange: (vec: { x: number; y: number }) => void
  ) => {
    if (!stickRef.current) return;
    const rect = stickRef.current.getBoundingClientRect();
    const touch = e.targetTouches[0];
    if (!touch) return;

    const centerX = rect.left + rect.width / 2;
    const centerY = rect.top + rect.height / 2;

    const dx = touch.clientX - centerX;
    const dy = touch.clientY - centerY;
    const maxDist = rect.width / 2;

    const dist = Math.hypot(dx, dy);
    const angle = Math.atan2(dy, dx);
    const clampedDist = Math.min(dist, maxDist);

    const nx = (Math.cos(angle) * clampedDist) / maxDist;
    const ny = (Math.sin(angle) * clampedDist) / maxDist;

    setPos({ x: Math.cos(angle) * clampedDist, y: Math.sin(angle) * clampedDist });
    onChange({ x: nx, y: ny });
  };

  const handleStickEnd = (
    setPos: (pos: { x: number; y: number }) => void,
    onChange: (vec: { x: number; y: number }) => void
  ) => {
    setPos({ x: 0, y: 0 });
    onChange({ x: 0, y: 0 });
  };

  return (
    <div className="absolute inset-0 pointer-events-none z-30 flex justify-between items-end p-6 select-none">
      {/* Left Move Stick */}
      <div
        ref={moveStickRef}
        onTouchMove={(e) => handleStickTouch(e, moveStickRef, setMovePos, onMoveChange)}
        onTouchStart={(e) => handleStickTouch(e, moveStickRef, setMovePos, onMoveChange)}
        onTouchEnd={() => handleStickEnd(setMovePos, onMoveChange)}
        className="pointer-events-auto relative w-28 h-28 rounded-full bg-neutral-900/60 border-2 border-neutral-600/60 flex items-center justify-center backdrop-blur-sm"
      >
        <div
          className="w-12 h-12 rounded-full bg-amber-500/80 border border-amber-300 shadow-md"
          style={{ transform: `translate(${movePos.x}px, ${movePos.y}px)` }}
        />
        <span className="absolute bottom-2 text-[9px] font-code text-neutral-400 uppercase">
          Move
        </span>
      </div>

      {/* Center Action Buttons */}
      <div className="pointer-events-auto flex items-center gap-2.5 mb-2">
        <button
          onClick={onPrevWeapon}
          className="p-3 bg-neutral-900/80 border border-neutral-700 rounded-full text-neutral-200 active:scale-95"
          title="Previous Weapon"
        >
          <ChevronLeft className="w-5 h-5" />
        </button>

        {onInteract && (
          <button
            onClick={onInteract}
            className="p-3.5 bg-amber-900/80 border border-amber-600 rounded-full text-amber-300 shadow-lg active:scale-95"
            title="Interact (Lore Note)"
          >
            <FileText className="w-5 h-5" />
          </button>
        )}

        <button
          onClick={onThrowMolotov}
          className="p-3.5 bg-red-900/80 border border-red-600 rounded-full text-amber-300 shadow-lg active:scale-95"
          title="Throw Molotov"
        >
          <Flame className="w-6 h-6" />
        </button>

        <button
          onClick={onReload}
          className="p-3.5 bg-neutral-900/80 border border-neutral-700 rounded-full text-neutral-200 active:scale-95"
          title="Reload"
        >
          <RotateCcw className="w-5 h-5" />
        </button>

        <button
          onClick={onNextWeapon}
          className="p-3 bg-neutral-900/80 border border-neutral-700 rounded-full text-neutral-200 active:scale-95"
          title="Next Weapon"
        >
          <ChevronRight className="w-5 h-5" />
        </button>
      </div>

      {/* Right Aim & Fire Stick */}
      <div
        ref={aimStickRef}
        onTouchMove={(e) => handleStickTouch(e, aimStickRef, setAimPos, onAimChange)}
        onTouchStart={(e) => handleStickTouch(e, aimStickRef, setAimPos, onAimChange)}
        onTouchEnd={() => handleStickEnd(setAimPos, onAimChange)}
        className="pointer-events-auto relative w-28 h-28 rounded-full bg-neutral-900/60 border-2 border-red-600/60 flex items-center justify-center backdrop-blur-sm"
      >
        <div
          className="w-12 h-12 rounded-full bg-red-600/80 border border-red-400 shadow-md"
          style={{ transform: `translate(${aimPos.x}px, ${aimPos.y}px)` }}
        />
        <span className="absolute bottom-2 text-[9px] font-code text-red-300 uppercase">
          Aim / Fire
        </span>
      </div>
    </div>
  );
};
