import React from 'react';
import { LoreNote } from '../types/game';
import { FileText, X, MapPin, Calendar, User, BookOpen } from 'lucide-react';

interface LoreNoteModalProps {
  note: LoreNote;
  onClose: () => void;
}

export const LoreNoteModal: React.FC<LoreNoteModalProps> = ({ note, onClose }) => {
  return (
    <div
      id="lore-note-modal"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm select-none"
      onClick={onClose}
    >
      <div
        className="relative w-full max-w-xl bg-[#1c1813] border-2 border-[#b45309]/70 rounded-lg shadow-2xl p-6 md:p-8 text-[#fef3c7] overflow-hidden"
        style={{
          boxShadow: '0 20px 50px rgba(0, 0, 0, 0.9), 0 0 25px rgba(245, 158, 11, 0.2)',
          backgroundImage: 'radial-gradient(ellipse at center, #292017 0%, #15120e 100%)',
        }}
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header Ribbon */}
        <div className="flex items-center justify-between border-b border-[#b45309]/40 pb-4 mb-4">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-amber-950/80 border border-amber-600/80 rounded-md text-amber-400">
              <FileText className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2 text-xs font-code tracking-wider text-amber-500 uppercase">
                <BookOpen className="w-3.5 h-3.5" />
                <span>Pike County Classified Lore</span>
              </div>
              <h2 className="text-xl md:text-2xl font-heading font-bold text-amber-100 tracking-wide">
                {note.title}
              </h2>
            </div>
          </div>

          <button
            id="close-lore-modal-btn"
            onClick={onClose}
            className="p-2 text-neutral-400 hover:text-white bg-neutral-900/60 hover:bg-neutral-800 border border-neutral-700/60 rounded-md transition cursor-pointer"
            title="Close Note (Esc)"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Note Metadata Details */}
        <div className="flex flex-wrap items-center gap-4 text-xs font-code text-amber-300/80 bg-black/40 border border-amber-900/40 px-3.5 py-2 rounded-md mb-5">
          <div className="flex items-center gap-1.5">
            <User className="w-3.5 h-3.5 text-amber-500" />
            <span>Author: <strong className="text-amber-200">{note.author}</strong></span>
          </div>
          <div className="flex items-center gap-1.5">
            <Calendar className="w-3.5 h-3.5 text-amber-500" />
            <span>Date: <strong className="text-amber-200">{note.date}</strong></span>
          </div>
          <div className="flex items-center gap-1.5">
            <MapPin className="w-3.5 h-3.5 text-amber-500" />
            <span>Sector: <strong className="text-amber-200 uppercase">{note.locationId.replace(/_/g, ' ')}</strong></span>
          </div>
        </div>

        {/* Content Body with aged typewriter / letter style */}
        <div className="space-y-3.5 font-serif text-sm md:text-base leading-relaxed text-amber-100/90 max-h-72 overflow-y-auto pr-2 custom-scrollbar">
          {note.content.map((paragraph, idx) => (
            <p
              key={idx}
              className="bg-amber-950/20 p-3 rounded border-l-2 border-amber-600/60 italic"
            >
              "{paragraph}"
            </p>
          ))}
        </div>

        {/* Discovery Bonus Alert & Footer */}
        <div className="mt-6 pt-4 border-t border-[#b45309]/30 flex items-center justify-between text-xs">
          <span className="text-emerald-400 font-heading font-semibold flex items-center gap-1">
            +250 Points • +50 Scrap Salvaged
          </span>
          <button
            id="dismiss-lore-modal-btn"
            onClick={onClose}
            className="px-4 py-2 bg-amber-600 hover:bg-amber-500 text-neutral-950 font-heading font-bold uppercase tracking-wider rounded transition shadow-lg cursor-pointer"
          >
            Resume Survival [Esc]
          </button>
        </div>
      </div>
    </div>
  );
};
