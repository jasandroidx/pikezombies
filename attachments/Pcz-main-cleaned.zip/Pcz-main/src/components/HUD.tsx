import React from 'react';
import { Weapon, ActivePowerup } from '../types/game';
import { Volume2, VolumeX, Flame, Wrench, Shield, Zap, Skull, Award, Infinity, Radio } from 'lucide-react';
import { soundEngine } from '../audio/soundEngine';

interface HUDProps {
  health: number;
  maxHealth: number;
  stamina: number;
  weapon: Weapon;
  molotovs: number;
  score: number;
  scrap: number;
  combo: number;
  wave: number;
  waveTimer: number;
  zombiesRemaining: number;
  isReloading: boolean;
  reloadProgress: number;
  isMuted: boolean;
  activePowerups?: ActivePowerup[];
  onToggleMute: () => void;
  onOpenWorkbench: () => void;
  onSkipWaveTimer: () => void;
  locationName: string;
}

export const HUD: React.FC<HUDProps> = ({
  health,
  maxHealth,
  stamina,
  weapon,
  molotovs,
  score,
  scrap,
  combo,
  wave,
  waveTimer,
  zombiesRemaining,
  isReloading,
  reloadProgress,
  isMuted,
  activePowerups = [],
  onToggleMute,
  onOpenWorkbench,
  onSkipWaveTimer,
  locationName,
}) => {
  const hpPercent = Math.max(0, Math.min(100, (health / maxHealth) * 100));
  const isCritical = hpPercent < 25;

  return (
    <div className="absolute inset-0 pointer-events-none flex flex-col justify-between p-4 md:p-6 select-none">
      {/* Critical Health Screen Edge Glow */}
      {isCritical && (
        <div className="absolute inset-0 bg-red-950/30 border-8 border-red-600/40 animate-pulse pointer-events-none" />
      )}

      {/* TOP BAR */}
      <div className="flex items-start justify-between w-full">
        {/* Wave & Objective */}
        <div className="flex flex-col gap-1">
          <div className="flex items-center gap-3 bg-neutral-900/90 border border-neutral-700/80 px-4 py-2 rounded shadow-2xl backdrop-blur-md">
            <div className="flex flex-col">
              <span className="text-[11px] uppercase tracking-widest text-amber-400/90 font-code font-bold">
                Appalachian Hollow
              </span>
              <div className="flex items-baseline gap-2">
                <span className="text-2xl md:text-3xl font-heading font-bold text-neutral-100 tracking-wider">
                  WAVE {wave}
                </span>
                {waveTimer > 0 ? (
                  <span className="text-xs text-amber-300 font-code animate-pulse">
                    NEXT WAVE IN {waveTimer}s
                  </span>
                ) : (
                  <span className="text-xs text-red-400 font-code">
                    {zombiesRemaining} INFECTED REMAINING
                  </span>
                )}
              </div>
            </div>

            {/* Skip Break Button */}
            {waveTimer > 0 && (
              <button
                id="skip-wave-btn"
                onClick={onSkipWaveTimer}
                className="pointer-events-auto cursor-pointer ml-3 px-3 py-1.5 bg-red-900/80 hover:bg-red-800 text-red-100 border border-red-600 text-xs font-heading font-bold tracking-wider rounded transition uppercase active:scale-95"
              >
                Engage Now
              </button>
            )}
          </div>

          <span className="text-xs text-neutral-400 font-code pl-1 flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping inline-block" />
            {locationName}
          </span>
        </div>

        {/* Score, Combo & Currency */}
        <div className="flex items-center gap-4">
          {/* Combo Multiplier */}
          {combo > 1 && (
            <div className="bg-red-900/90 border border-red-600 px-3 py-1.5 rounded text-red-100 shadow-lg animate-bounce flex items-center gap-1.5">
              <Zap className="w-4 h-4 text-amber-300" />
              <span className="text-sm md:text-base font-heading font-bold tracking-widest text-amber-300">
                {combo.toFixed(1)}x STREAK
              </span>
            </div>
          )}

          {/* Scrap Metal & Score */}
          <div className="bg-neutral-900/90 border border-neutral-700/80 px-4 py-2 rounded shadow-2xl backdrop-blur-md flex items-center gap-5">
            <div className="flex flex-col items-end">
              <span className="text-[10px] text-neutral-400 uppercase font-code tracking-wider">
                Scrap Salvage
              </span>
              <div className="flex items-center gap-1.5 text-amber-400 font-heading font-bold text-lg md:text-xl">
                <Wrench className="w-4 h-4 text-neutral-400" />
                <span>{scrap}</span>
              </div>
            </div>

            <div className="w-[1px] h-8 bg-neutral-700/60" />

            <div className="flex flex-col items-end">
              <span className="text-[10px] text-neutral-400 uppercase font-code tracking-wider">
                Total Score
              </span>
              <span className="text-neutral-100 font-heading font-bold text-lg md:text-xl tracking-wider">
                {score.toLocaleString()}
              </span>
            </div>
          </div>

          {/* Action buttons: Sound & Workbench */}
          <div className="flex items-center gap-2 pointer-events-auto">
            <button
              id="hud-workbench-btn"
              onClick={onOpenWorkbench}
              className="bg-neutral-900/90 hover:bg-neutral-800 text-amber-400 hover:text-amber-300 border border-neutral-700 p-2.5 rounded shadow-xl transition cursor-pointer flex items-center gap-1.5 active:scale-95"
              title="Open Gunsmith Workbench (TAB)"
            >
              <Wrench className="w-5 h-5" />
              <span className="hidden md:inline font-heading text-xs uppercase font-bold tracking-wider">
                Workbench
              </span>
            </button>

            <button
              id="hud-sound-btn"
              onClick={onToggleMute}
              className="bg-neutral-900/90 hover:bg-neutral-800 text-neutral-200 border border-neutral-700 p-2.5 rounded shadow-xl transition cursor-pointer active:scale-95"
              title="Toggle Audio (M)"
            >
              {isMuted ? <VolumeX className="w-5 h-5 text-red-400" /> : <Volume2 className="w-5 h-5 text-emerald-400" />}
            </button>
          </div>
        </div>
      </div>

      {/* ACTIVE POWERUPS ROW */}
      {activePowerups.length > 0 && (
        <div className="flex items-center justify-center gap-3 w-full my-auto pointer-events-none">
          {activePowerups.map((p) => {
            const pct = Math.max(0, Math.min(100, (p.durationRemaining / p.totalDuration) * 100));
            const secs = Math.ceil(p.durationRemaining / 1000);
            const isFlashing = p.durationRemaining < 3000;

            let name = 'POWERUP';
            let colorBorder = 'border-amber-500';
            let colorBg = 'bg-amber-950/80';
            let textColor = 'text-amber-300';
            let barColor = 'bg-amber-400';
            let icon = <Zap className="w-4 h-4" />;

            if (p.type === 'insta_kill') {
              name = 'INSTA-KILL';
              colorBorder = 'border-red-600';
              colorBg = 'bg-red-950/80';
              textColor = 'text-red-300';
              barColor = 'bg-red-500';
              icon = <Skull className="w-4 h-4 text-red-300" />;
            } else if (p.type === 'double_points') {
              name = 'DOUBLE POINTS (2X)';
              colorBorder = 'border-emerald-600';
              colorBg = 'bg-emerald-950/80';
              textColor = 'text-emerald-300';
              barColor = 'bg-emerald-500';
              icon = <Award className="w-4 h-4 text-emerald-300" />;
            } else if (p.type === 'infinite_ammo') {
              name = 'INFINITE AMMO';
              colorBorder = 'border-blue-600';
              colorBg = 'bg-blue-950/80';
              textColor = 'text-blue-300';
              barColor = 'bg-blue-500';
              icon = <Infinity className="w-4 h-4 text-blue-300" />;
            } else if (p.type === 'speed_boost') {
              name = 'ADRENALINE OVERDRIVE';
              colorBorder = 'border-purple-600';
              colorBg = 'bg-purple-950/80';
              textColor = 'text-purple-300';
              barColor = 'bg-purple-500';
              icon = <Zap className="w-4 h-4 text-purple-300" />;
            }

            return (
              <div
                key={p.type}
                className={`flex flex-col gap-1 px-3.5 py-2 rounded border backdrop-blur-md shadow-2xl transition-all ${colorBorder} ${colorBg} ${
                  isFlashing ? 'animate-pulse' : ''
                }`}
              >
                <div className="flex items-center justify-between gap-3">
                  <div className="flex items-center gap-1.5">
                    {icon}
                    <span className={`text-xs font-heading font-bold uppercase tracking-wider ${textColor}`}>
                      {name}
                    </span>
                  </div>
                  <span className="font-code text-xs font-bold text-neutral-200">
                    {secs}s
                  </span>
                </div>
                <div className="w-36 h-1.5 bg-neutral-900 rounded-full overflow-hidden">
                  <div
                    className={`h-full ${barColor} transition-all duration-100`}
                    style={{ width: `${pct}%` }}
                  />
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* BOTTOM BAR */}
      <div className="flex items-end justify-between w-full">
        {/* Health & Stamina */}
        <div className="flex flex-col gap-2 w-64 md:w-80 bg-neutral-900/90 border border-neutral-700/80 p-3.5 rounded shadow-2xl backdrop-blur-md">
          {/* Health */}
          <div>
            <div className="flex justify-between items-center text-xs font-heading font-bold mb-1">
              <span className="flex items-center gap-1 text-red-400 uppercase tracking-wider">
                <Shield className="w-3.5 h-3.5" /> Vitality
              </span>
              <span className="font-code text-neutral-200">
                {Math.ceil(health)} / {maxHealth}
              </span>
            </div>
            <div className="h-3 w-full bg-neutral-950 rounded-full overflow-hidden border border-neutral-800">
              <div
                className={`h-full transition-all duration-150 ${
                  isCritical ? 'bg-red-600 animate-pulse' : hpPercent < 50 ? 'bg-amber-500' : 'bg-red-500'
                }`}
                style={{ width: `${hpPercent}%` }}
              />
            </div>
          </div>

          {/* Stamina */}
          <div>
            <div className="flex justify-between items-center text-[10px] font-heading font-bold mb-0.5">
              <span className="flex items-center gap-1 text-emerald-400 uppercase tracking-wider">
                <Zap className="w-3 h-3" /> Adrenaline / Sprint
              </span>
              <span className="font-code text-neutral-400">
                {Math.ceil(stamina)}%
              </span>
            </div>
            <div className="h-1.5 w-full bg-neutral-950 rounded-full overflow-hidden border border-neutral-800">
              <div
                className="h-full bg-emerald-500 transition-all duration-75"
                style={{ width: `${stamina}%` }}
              />
            </div>
          </div>
        </div>

        {/* Center: Molotov Quick Throw */}
        <div className="bg-neutral-900/90 border border-neutral-700/80 px-4 py-2.5 rounded shadow-2xl backdrop-blur-md flex items-center gap-3">
          <div className="flex items-center gap-2">
            <div className="relative">
              <Flame className="w-6 h-6 text-amber-500" />
              <span className="absolute -bottom-1 -right-1 bg-red-700 text-white font-code text-[10px] font-bold px-1 rounded-full">
                {molotovs}
              </span>
            </div>
            <div className="flex flex-col">
              <span className="text-xs font-heading font-bold text-neutral-200 uppercase tracking-wider">
                Moonshine Molotov
              </span>
              <span className="text-[10px] text-neutral-400 font-code">
                [SPACE / Q / Right Click]
              </span>
            </div>
          </div>
        </div>

        {/* Active Weapon Card */}
        <div className="flex flex-col gap-1 w-64 md:w-80 bg-neutral-900/90 border border-neutral-700/80 p-3.5 rounded shadow-2xl backdrop-blur-md">
          <div className="flex justify-between items-center">
            <span className="text-[10px] text-amber-400 uppercase font-code tracking-wider">
              {weapon.category} [Slot {weapon.soundType === 'chainsaw' ? '6' : '1-5'}]
            </span>
            <span className="text-xs font-code text-neutral-400">
              Lv. {weapon.upgradeLevel}
            </span>
          </div>

          <div className="flex items-baseline justify-between mt-0.5">
            <span className="text-lg md:text-xl font-heading font-bold text-neutral-100 truncate pr-2">
              {weapon.name}
            </span>
            <div className="flex items-baseline gap-1 font-code font-bold">
              <span className={`text-2xl ${weapon.currentMag === 0 ? 'text-red-500 animate-bounce' : 'text-neutral-100'}`}>
                {weapon.currentMag}
              </span>
              <span className="text-neutral-500 text-base">/</span>
              <span className="text-neutral-400 text-sm">
                {weapon.reserveAmmo}
              </span>
            </div>
          </div>

          {/* Reload indicator */}
          {isReloading ? (
            <div className="mt-1">
              <div className="flex justify-between text-[10px] font-code text-amber-400 mb-0.5">
                <span>RELOADING...</span>
                <span>{Math.round(reloadProgress * 100)}%</span>
              </div>
              <div className="h-1.5 w-full bg-neutral-950 rounded-full overflow-hidden border border-neutral-800">
                <div
                  className="h-full bg-amber-400 transition-all duration-75"
                  style={{ width: `${reloadProgress * 100}%` }}
                />
              </div>
            </div>
          ) : (
            <div className="flex justify-between text-[10px] text-neutral-500 font-code mt-0.5">
              <span>Press [R] to reload</span>
              <span>Scroll to switch</span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
