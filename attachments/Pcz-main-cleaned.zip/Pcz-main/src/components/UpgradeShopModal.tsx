import React, { useState } from 'react';
import { Weapon, Perk } from '../types/game';
import { Wrench, Shield, Zap, Sun, Package, Flame, Target, X, Check, ShoppingCart } from 'lucide-react';
import { soundEngine } from '../audio/soundEngine';

interface UpgradeShopModalProps {
  weapons: Weapon[];
  perks: Perk[];
  scrap: number;
  molotovs: number;
  maxMolotovs: number;
  onClose: () => void;
  onUnlockWeapon: (weaponIndex: number) => void;
  onUpgradeWeapon: (weaponIndex: number) => void;
  onUpgradePerk: (perkId: string) => void;
  onBuyAmmoRefill: () => void;
  onBuyMolotov: () => void;
}

export const UpgradeShopModal: React.FC<UpgradeShopModalProps> = ({
  weapons,
  perks,
  scrap,
  molotovs,
  maxMolotovs,
  onClose,
  onUnlockWeapon,
  onUpgradeWeapon,
  onUpgradePerk,
  onBuyAmmoRefill,
  onBuyMolotov,
}) => {
  const [activeTab, setActiveTab] = useState<'weapons' | 'perks' | 'supplies'>('weapons');

  const getPerkIcon = (iconName: string) => {
    switch (iconName) {
      case 'Shield': return <Shield className="w-5 h-5 text-emerald-400" />;
      case 'Zap': return <Zap className="w-5 h-5 text-amber-400" />;
      case 'Sun': return <Sun className="w-5 h-5 text-yellow-300" />;
      case 'Package': return <Package className="w-5 h-5 text-blue-400" />;
      case 'Flame': return <Flame className="w-5 h-5 text-red-500" />;
      case 'Target': return <Target className="w-5 h-5 text-rose-400" />;
      default: return <Wrench className="w-5 h-5 text-neutral-400" />;
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-4 animate-in fade-in duration-200">
      <div className="bg-neutral-900 border border-neutral-700 w-full max-w-4xl rounded-lg shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="bg-neutral-950 border-b border-neutral-800 p-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-amber-500/10 border border-amber-500/30 rounded">
              <Wrench className="w-6 h-6 text-amber-400" />
            </div>
            <div>
              <h2 className="text-xl md:text-2xl font-heading font-bold text-neutral-100 tracking-wider">
                APPALACHIAN GUNSMITH & STILL
              </h2>
              <p className="text-xs text-neutral-400 font-code">
                Modify firearms, brew 190-proof moonshine, and reinforce mountain survival skills.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-4">
            {/* Scrap Counter */}
            <div className="flex items-center gap-2 bg-neutral-900 border border-neutral-700 px-3 py-1.5 rounded">
              <span className="text-xs text-neutral-400 uppercase font-code">Scrap:</span>
              <span className="text-lg font-heading font-bold text-amber-400">{scrap}</span>
            </div>

            <button
              id="shop-close-btn"
              onClick={onClose}
              className="p-2 text-neutral-400 hover:text-white rounded hover:bg-neutral-800 transition cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex border-b border-neutral-800 bg-neutral-950/60 px-4">
          <button
            id="shop-tab-weapons"
            onClick={() => setActiveTab('weapons')}
            className={`py-3 px-5 font-heading font-bold text-sm tracking-wider uppercase border-b-2 transition cursor-pointer ${
              activeTab === 'weapons'
                ? 'border-amber-500 text-amber-400'
                : 'border-transparent text-neutral-400 hover:text-neutral-200'
            }`}
          >
            Firearms & Arsenal
          </button>
          <button
            id="shop-tab-perks"
            onClick={() => setActiveTab('perks')}
            className={`py-3 px-5 font-heading font-bold text-sm tracking-wider uppercase border-b-2 transition cursor-pointer ${
              activeTab === 'perks'
                ? 'border-amber-500 text-amber-400'
                : 'border-transparent text-neutral-400 hover:text-neutral-200'
            }`}
          >
            Mountain Perks
          </button>
          <button
            id="shop-tab-supplies"
            onClick={() => setActiveTab('supplies')}
            className={`py-3 px-5 font-heading font-bold text-sm tracking-wider uppercase border-b-2 transition cursor-pointer ${
              activeTab === 'supplies'
                ? 'border-amber-500 text-amber-400'
                : 'border-transparent text-neutral-400 hover:text-neutral-200'
            }`}
          >
            Munitions & Moonshine
          </button>
        </div>

        {/* Content Area */}
        <div className="p-5 overflow-y-auto flex-1 custom-scrollbar">
          {/* WEAPONS TAB */}
          {activeTab === 'weapons' && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {weapons.map((wep, idx) => {
                const upgradeCost = Math.round(wep.damage * 4.5 * wep.upgradeLevel);
                const canAffordUpgrade = scrap >= upgradeCost;
                const canAffordUnlock = scrap >= wep.cost;

                return (
                  <div
                    key={wep.id}
                    className="bg-neutral-950/70 border border-neutral-800 rounded p-4 flex flex-col justify-between"
                  >
                    <div>
                      <div className="flex justify-between items-start mb-1">
                        <div>
                          <span className="text-[10px] uppercase font-code text-amber-400/90 tracking-wider">
                            {wep.category}
                          </span>
                          <h3 className="text-lg font-heading font-bold text-neutral-100">
                            {wep.name}
                          </h3>
                        </div>
                        {wep.unlocked ? (
                          <span className="text-xs bg-emerald-950/80 border border-emerald-700/80 text-emerald-400 px-2 py-0.5 rounded font-code">
                            Lv. {wep.upgradeLevel}
                          </span>
                        ) : (
                          <span className="text-xs bg-red-950/80 border border-red-700/80 text-red-400 px-2 py-0.5 rounded font-code">
                            Locked
                          </span>
                        )}
                      </div>

                      <p className="text-xs text-neutral-400 font-sans mb-3 line-clamp-2">
                        {wep.description}
                      </p>

                      <div className="grid grid-cols-3 gap-2 bg-neutral-900/60 p-2.5 rounded border border-neutral-800/80 mb-3 text-center">
                        <div>
                          <span className="text-[10px] text-neutral-500 block uppercase font-code">Damage</span>
                          <span className="text-sm font-code font-bold text-neutral-200">{Math.round(wep.damage)}</span>
                        </div>
                        <div>
                          <span className="text-[10px] text-neutral-500 block uppercase font-code">Mag Cap</span>
                          <span className="text-sm font-code font-bold text-neutral-200">{wep.magazineSize}</span>
                        </div>
                        <div>
                          <span className="text-[10px] text-neutral-500 block uppercase font-code">Fire Rate</span>
                          <span className="text-sm font-code font-bold text-neutral-200">{wep.fireRate}/s</span>
                        </div>
                      </div>
                    </div>

                    <div>
                      {wep.unlocked ? (
                        <button
                          id={`upgrade-weapon-${wep.id}`}
                          onClick={() => {
                            if (canAffordUpgrade) {
                              onUpgradeWeapon(idx);
                              soundEngine.playPickup();
                            }
                          }}
                          disabled={!canAffordUpgrade}
                          className={`w-full py-2 px-3 rounded font-heading font-bold text-xs uppercase tracking-wider transition flex items-center justify-center gap-2 cursor-pointer ${
                            canAffordUpgrade
                              ? 'bg-amber-600 hover:bg-amber-500 text-neutral-950 active:scale-95'
                              : 'bg-neutral-800 text-neutral-500 cursor-not-allowed'
                          }`}
                        >
                          <Wrench className="w-4 h-4" />
                          <span>Upgrade (+20% Power) - {upgradeCost} Scrap</span>
                        </button>
                      ) : (
                        <button
                          id={`unlock-weapon-${wep.id}`}
                          onClick={() => {
                            if (canAffordUnlock) {
                              onUnlockWeapon(idx);
                              soundEngine.playPickup();
                            }
                          }}
                          disabled={!canAffordUnlock}
                          className={`w-full py-2 px-3 rounded font-heading font-bold text-xs uppercase tracking-wider transition flex items-center justify-center gap-2 cursor-pointer ${
                            canAffordUnlock
                              ? 'bg-emerald-600 hover:bg-emerald-500 text-neutral-950 active:scale-95'
                              : 'bg-neutral-800 text-neutral-500 cursor-not-allowed'
                          }`}
                        >
                          <ShoppingCart className="w-4 h-4" />
                          <span>Unlock Weapon - {wep.cost} Scrap</span>
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          {/* PERKS TAB */}
          {activeTab === 'perks' && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {perks.map((perk) => {
                const isMax = perk.level >= perk.maxLevel;
                const cost = perk.cost * (perk.level + 1);
                const canAfford = scrap >= cost && !isMax;

                return (
                  <div
                    key={perk.id}
                    className="bg-neutral-950/70 border border-neutral-800 rounded p-4 flex flex-col justify-between"
                  >
                    <div className="flex items-start gap-3 mb-3">
                      <div className="p-2.5 bg-neutral-900 border border-neutral-800 rounded">
                        {getPerkIcon(perk.icon)}
                      </div>
                      <div className="flex-1">
                        <div className="flex justify-between items-center mb-1">
                          <h3 className="text-base font-heading font-bold text-neutral-100">
                            {perk.name}
                          </h3>
                          <span className="text-xs font-code text-amber-400">
                            Rank {perk.level}/{perk.maxLevel}
                          </span>
                        </div>
                        <p className="text-xs text-neutral-400 font-sans">
                          {perk.description}
                        </p>
                      </div>
                    </div>

                    <button
                      id={`upgrade-perk-${perk.id}`}
                      onClick={() => {
                        if (canAfford) {
                          onUpgradePerk(perk.id);
                          soundEngine.playPickup();
                        }
                      }}
                      disabled={!canAfford}
                      className={`w-full py-2 px-3 rounded font-heading font-bold text-xs uppercase tracking-wider transition flex items-center justify-center gap-2 cursor-pointer ${
                        isMax
                          ? 'bg-neutral-800/60 text-emerald-400 border border-emerald-800/40 cursor-default'
                          : canAfford
                          ? 'bg-amber-600 hover:bg-amber-500 text-neutral-950 active:scale-95'
                          : 'bg-neutral-800 text-neutral-500 cursor-not-allowed'
                      }`}
                    >
                      {isMax ? (
                        <>
                          <Check className="w-4 h-4" />
                          <span>Maxed Out</span>
                        </>
                      ) : (
                        <span>Train Perk ({cost} Scrap)</span>
                      )}
                    </button>
                  </div>
                );
              })}
            </div>
          )}

          {/* SUPPLIES TAB */}
          {activeTab === 'supplies' && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Universal Ammo Cache */}
              <div className="bg-neutral-950/70 border border-neutral-800 rounded p-4 flex flex-col justify-between">
                <div>
                  <div className="flex items-center gap-3 mb-2">
                    <div className="p-2 bg-emerald-950/60 border border-emerald-700/60 rounded">
                      <Package className="w-6 h-6 text-emerald-400" />
                    </div>
                    <div>
                      <h3 className="text-base font-heading font-bold text-neutral-100">
                        Universal Munitions Cache
                      </h3>
                      <p className="text-xs text-neutral-400 font-sans">
                        Full resupply of shells, rifle cartridges, and magnum rounds for all owned guns.
                      </p>
                    </div>
                  </div>
                </div>

                <button
                  id="buy-ammo-cache-btn"
                  onClick={() => {
                    if (scrap >= 80) {
                      onBuyAmmoRefill();
                      soundEngine.playPickup();
                    }
                  }}
                  disabled={scrap < 80}
                  className={`w-full mt-4 py-2 px-3 rounded font-heading font-bold text-xs uppercase tracking-wider transition flex items-center justify-center gap-2 cursor-pointer ${
                    scrap >= 80
                      ? 'bg-emerald-600 hover:bg-emerald-500 text-neutral-950 active:scale-95'
                      : 'bg-neutral-800 text-neutral-500 cursor-not-allowed'
                  }`}
                >
                  <ShoppingCart className="w-4 h-4" />
                  <span>Resupply Ammo (80 Scrap)</span>
                </button>
              </div>

              {/* Mason Jar Moonshine Cocktail */}
              <div className="bg-neutral-950/70 border border-neutral-800 rounded p-4 flex flex-col justify-between">
                <div>
                  <div className="flex items-center gap-3 mb-2">
                    <div className="p-2 bg-red-950/60 border border-red-700/60 rounded">
                      <Flame className="w-6 h-6 text-red-400" />
                    </div>
                    <div>
                      <h3 className="text-base font-heading font-bold text-neutral-100">
                        190-Proof Moonshine Molotov
                      </h3>
                      <p className="text-xs text-neutral-400 font-sans">
                        Craft an incendiary bottle that blankets the ground in raging fire. ({molotovs}/{maxMolotovs} carried)
                      </p>
                    </div>
                  </div>
                </div>

                <button
                  id="buy-molotov-btn"
                  onClick={() => {
                    if (scrap >= 60 && molotovs < maxMolotovs) {
                      onBuyMolotov();
                      soundEngine.playPickup();
                    }
                  }}
                  disabled={scrap < 60 || molotovs >= maxMolotovs}
                  className={`w-full mt-4 py-2 px-3 rounded font-heading font-bold text-xs uppercase tracking-wider transition flex items-center justify-center gap-2 cursor-pointer ${
                    scrap >= 60 && molotovs < maxMolotovs
                      ? 'bg-amber-600 hover:bg-amber-500 text-neutral-950 active:scale-95'
                      : 'bg-neutral-800 text-neutral-500 cursor-not-allowed'
                  }`}
                >
                  <ShoppingCart className="w-4 h-4" />
                  <span>
                    {molotovs >= maxMolotovs ? 'Inventory Full' : 'Distill Bottle (60 Scrap)'}
                  </span>
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="bg-neutral-950 border-t border-neutral-800 p-4 flex justify-between items-center">
          <span className="text-xs text-neutral-500 font-code">
            Press [TAB] or [ESC] to resume battle
          </span>
          <button
            id="shop-resume-battle-btn"
            onClick={onClose}
            className="px-5 py-2 bg-amber-600 hover:bg-amber-500 text-neutral-950 font-heading font-bold text-sm tracking-wider uppercase rounded transition cursor-pointer active:scale-95"
          >
            Resume Battle
          </button>
        </div>
      </div>
    </div>
  );
};
