import React, { useState } from 'react';
import { GAME_LOCATIONS } from '../game/constants';
import { Play, Volume2, VolumeX, Shield, Trophy, Flame, Crosshair, HelpCircle } from 'lucide-react';
import { soundEngine } from '../audio/soundEngine';

interface StartScreenProps {
  onStartGame: (locationIndex: number, difficulty: number) => void;
  isMuted: boolean;
  onToggleMute: () => void;
}

export const StartScreen: React.FC<StartScreenProps> = ({
  onStartGame,
  isMuted,
  onToggleMute,
}) => {
  const [selectedLocation, setSelectedLocation] = useState<number>(0);
  const [selectedDifficulty, setSelectedDifficulty] = useState<number>(1.0);
  const [showHelp, setShowHelp] = useState<boolean>(false);

  const highScore = parseInt(localStorage.getItem('pike_county_high_score') || '0', 10);

  const handleStart = () => {
    soundEngine.init();
    onStartGame(selectedLocation, selectedDifficulty);
  };

  return (
    <div className="absolute inset-0 z-40 flex flex-col justify-between p-6 md:p-10 bg-neutral-950/95 overflow-y-auto custom-scrollbar">
      {/* Background Gritty Appalachian Atmosphere */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-neutral-900 via-neutral-950 to-black -z-10 pointer-events-none" />
      <div className="vignette-overlay absolute inset-0 -z-10 pointer-events-none" />

      {/* Top Header */}
      <div className="flex justify-between items-center w-full max-w-6xl mx-auto">
        <div className="flex items-center gap-2">
          <span className="w-2.5 h-2.5 rounded-full bg-red-600 animate-pulse" />
          <span className="text-xs uppercase font-code tracking-widest text-neutral-400">
            Pike County Quarantine Zone • Hazard Lv. 5
          </span>
        </div>

        <div className="flex items-center gap-3">
          {highScore > 0 && (
            <div className="flex items-center gap-1.5 bg-neutral-900/80 border border-neutral-800 px-3 py-1 rounded text-xs font-heading font-bold text-amber-400">
              <Trophy className="w-3.5 h-3.5 text-amber-400" />
              <span>Record: {highScore.toLocaleString()}</span>
            </div>
          )}

          <button
            id="start-help-btn"
            onClick={() => setShowHelp(!showHelp)}
            className="p-2 bg-neutral-900/80 hover:bg-neutral-800 text-neutral-300 border border-neutral-800 rounded transition cursor-pointer"
            title="Field Manual & Controls"
          >
            <HelpCircle className="w-4 h-4" />
          </button>

          <button
            id="start-sound-btn"
            onClick={onToggleMute}
            className="p-2 bg-neutral-900/80 hover:bg-neutral-800 text-neutral-300 border border-neutral-800 rounded transition cursor-pointer"
            title="Toggle Audio"
          >
            {isMuted ? <VolumeX className="w-4 h-4 text-red-400" /> : <Volume2 className="w-4 h-4 text-emerald-400" />}
          </button>
        </div>
      </div>

      {/* Main Center Content */}
      <div className="flex flex-col items-center justify-center my-auto py-8 max-w-4xl mx-auto w-full text-center">
        {/* Title */}
        <div className="mb-8">
          <h1 className="text-4xl sm:text-6xl md:text-7xl font-display font-black tracking-wider text-red-600 drop-shadow-[0_10px_25px_rgba(220,38,38,0.35)]">
            PIKE COUNTY
          </h1>
          <div className="text-2xl sm:text-3xl md:text-4xl font-heading font-bold tracking-widest text-neutral-100 uppercase mt-1">
            ZOMBIES
          </div>
          <p className="text-xs sm:text-sm font-code text-neutral-400 max-w-md mx-auto mt-2 tracking-wide">
            Survive ruthless infected hordes in the dark Appalachian hollows and abandoned anthracite coal mines.
          </p>
        </div>

        {/* Location Selector */}
        <div className="w-full mb-6">
          <div className="text-xs uppercase font-code tracking-widest text-amber-400 mb-3 text-left">
            Select County Hotspot
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            {GAME_LOCATIONS.map((loc, idx) => (
              <button
                key={loc.id}
                id={`location-card-${loc.id}`}
                onClick={() => setSelectedLocation(idx)}
                className={`p-4 rounded border text-left transition cursor-pointer ${
                  selectedLocation === idx
                    ? 'bg-red-950/40 border-red-500 shadow-lg shadow-red-950/50 ring-1 ring-red-500'
                    : 'bg-neutral-900/60 border-neutral-800 hover:border-neutral-700 hover:bg-neutral-900'
                }`}
              >
                <span className="text-[10px] font-code text-amber-400/90 block">
                  {loc.countyZone}
                </span>
                <span className="text-base font-heading font-bold text-neutral-100 block mt-0.5">
                  {loc.name}
                </span>
                <p className="text-xs text-neutral-400 line-clamp-2 mt-1 font-sans">
                  {loc.description}
                </p>
              </button>
            ))}
          </div>
        </div>

        {/* Difficulty Selector */}
        <div className="w-full mb-8">
          <div className="text-xs uppercase font-code tracking-widest text-amber-400 mb-3 text-left">
            Threat Difficulty
          </div>
          <div className="grid grid-cols-3 gap-3">
            {[
              { level: 0.8, title: 'Greenhorn', desc: 'Slower hordes, higher ammo discovery' },
              { level: 1.0, title: 'Mountain Man', desc: 'Standard Appalachian survival' },
              { level: 1.4, title: 'Nightmare Hollow', desc: 'Aggressive sprinters & lethal boss spawns' },
            ].map((diff) => (
              <button
                key={diff.level}
                id={`diff-btn-${diff.title}`}
                onClick={() => setSelectedDifficulty(diff.level)}
                className={`p-3 rounded border text-center transition cursor-pointer ${
                  selectedDifficulty === diff.level
                    ? 'bg-amber-950/40 border-amber-500 text-amber-300 ring-1 ring-amber-500'
                    : 'bg-neutral-900/60 border-neutral-800 text-neutral-400 hover:border-neutral-700'
                }`}
              >
                <div className="text-sm font-heading font-bold uppercase tracking-wider">
                  {diff.title}
                </div>
                <div className="text-[11px] text-neutral-500 mt-0.5 font-sans">
                  {diff.desc}
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Launch Button */}
        <button
          id="start-launch-game-btn"
          onClick={handleStart}
          className="group relative px-10 py-4 bg-red-700 hover:bg-red-600 text-white font-heading font-bold text-xl uppercase tracking-widest rounded shadow-2xl shadow-red-900/80 transition-all cursor-pointer transform hover:scale-105 active:scale-95 flex items-center gap-3"
        >
          <Play className="w-6 h-6 fill-white" />
          <span>Enter the Hollow</span>
        </button>
      </div>

      {/* Field Manual Modal Overlay */}
      {showHelp && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4">
          <div className="bg-neutral-900 border border-neutral-700 w-full max-w-lg rounded-lg p-6 text-left shadow-2xl">
            <div className="flex justify-between items-center mb-4 border-b border-neutral-800 pb-3">
              <h3 className="text-xl font-heading font-bold text-neutral-100 uppercase tracking-wider flex items-center gap-2">
                <Crosshair className="w-5 h-5 text-red-500" />
                Appalachian Survival Manual
              </h3>
              <button
                onClick={() => setShowHelp(false)}
                className="text-neutral-400 hover:text-white font-code text-sm"
              >
                [CLOSE]
              </button>
            </div>

            <div className="space-y-3 text-sm text-neutral-300 font-sans mb-6">
              <div className="flex justify-between border-b border-neutral-800/60 pb-1">
                <span className="font-code text-amber-400">WASD / Arrow Keys</span>
                <span>Move & Maneuver</span>
              </div>
              <div className="flex justify-between border-b border-neutral-800/60 pb-1">
                <span className="font-code text-amber-400">Mouse Move / Stick</span>
                <span>Aim Flashlight & Weapons</span>
              </div>
              <div className="flex justify-between border-b border-neutral-800/60 pb-1">
                <span className="font-code text-amber-400">Left Click / Tap</span>
                <span>Fire Weapon</span>
              </div>
              <div className="flex justify-between border-b border-neutral-800/60 pb-1">
                <span className="font-code text-amber-400">Right Click / Space / Q</span>
                <span>Throw Moonshine Molotov</span>
              </div>
              <div className="flex justify-between border-b border-neutral-800/60 pb-1">
                <span className="font-code text-amber-400">Shift</span>
                <span>Sprint (Consumes Adrenaline)</span>
              </div>
              <div className="flex justify-between border-b border-neutral-800/60 pb-1">
                <span className="font-code text-amber-400">R</span>
                <span>Reload Magazine</span>
              </div>
              <div className="flex justify-between border-b border-neutral-800/60 pb-1">
                <span className="font-code text-amber-400">1 - 6 / Scroll</span>
                <span>Switch Firearms & Chainsaw</span>
              </div>
              <div className="flex justify-between">
                <span className="font-code text-amber-400">TAB / Workbench Btn</span>
                <span>Gunsmith Shop & Perks</span>
              </div>
            </div>

            <button
              onClick={() => setShowHelp(false)}
              className="w-full py-2.5 bg-neutral-800 hover:bg-neutral-700 text-neutral-200 font-heading font-bold text-sm tracking-wider uppercase rounded"
            >
              Understood
            </button>
          </div>
        </div>
      )}

      {/* Bottom Footer Note */}
      <div className="text-center text-xs text-neutral-500 font-code w-full max-w-6xl mx-auto">
        Pike County Quarantine Zone • Made with HTML5 Canvas 2D & Procedural Audio Engine
      </div>
    </div>
  );
};
