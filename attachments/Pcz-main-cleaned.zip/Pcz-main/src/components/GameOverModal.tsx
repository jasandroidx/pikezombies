import React, { useEffect, useState } from 'react';
import { PlayerStats } from '../types/game';
import { Skull, RotateCcw, Home, Award, Crosshair, Trophy } from 'lucide-react';
import confetti from 'canvas-confetti';

interface GameOverModalProps {
  stats: PlayerStats;
  score: number;
  wave: number;
  onRestart: () => void;
  onHome: () => void;
}

export const GameOverModal: React.FC<GameOverModalProps> = ({
  stats,
  score,
  wave,
  onRestart,
  onHome,
}) => {
  const [highScore, setHighScore] = useState<number>(0);
  const [isNewRecord, setIsNewRecord] = useState<boolean>(false);

  useEffect(() => {
    const stored = parseInt(localStorage.getItem('pike_county_high_score') || '0', 10);
    if (score > stored) {
      localStorage.setItem('pike_county_high_score', score.toString());
      setHighScore(score);
      setIsNewRecord(true);
      confetti({
        particleCount: 70,
        spread: 80,
        origin: { y: 0.6 },
        colors: ['#ef4444', '#f59e0b', '#10b981'],
      });
    } else {
      setHighScore(stored);
    }
  }, [score]);

  const accuracy = stats.shotsFired > 0
    ? Math.round((stats.shotsHit / stats.shotsFired) * 100)
    : 0;

  const minutes = Math.floor(stats.survivalTime / 60);
  const seconds = stats.survivalTime % 60;

  const getSurvivorTitle = () => {
    if (wave >= 15) return 'Appalachian Folk Legend';
    if (wave >= 10) return 'Devil\'s Backbone Warden';
    if (wave >= 5) return 'Hardened Ridge Runner';
    if (wave >= 3) return 'Hollow Defender';
    return 'Coal Dust Martyr';
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/90 backdrop-blur-lg p-4 animate-in fade-in duration-300">
      <div className="bg-neutral-900 border border-neutral-700 w-full max-w-xl rounded-lg shadow-2xl overflow-hidden flex flex-col">
        {/* Banner */}
        <div className="bg-red-950/60 border-b border-red-800/80 p-6 text-center">
          <div className="inline-flex p-3 bg-red-900/40 border border-red-700/60 rounded-full mb-3">
            <Skull className="w-10 h-10 text-red-500 animate-pulse" />
          </div>
          <h2 className="text-3xl md:text-4xl font-display font-bold text-red-100 tracking-wider">
            OVERRUN IN PIKE COUNTY
          </h2>
          <p className="text-sm font-heading tracking-widest text-amber-400 uppercase mt-1">
            {getSurvivorTitle()}
          </p>
        </div>

        {/* Score & Record */}
        <div className="bg-neutral-950 p-6 text-center border-b border-neutral-800">
          <div className="text-xs text-neutral-400 uppercase font-code tracking-widest mb-1">
            Final Score
          </div>
          <div className="text-4xl md:text-5xl font-heading font-bold text-neutral-100 tracking-wider">
            {score.toLocaleString()}
          </div>

          {isNewRecord ? (
            <div className="inline-flex items-center gap-1.5 mt-2 bg-amber-500/20 text-amber-400 border border-amber-500/40 px-3 py-1 rounded-full text-xs font-heading font-bold uppercase tracking-wider animate-bounce">
              <Trophy className="w-4 h-4" /> New Appalachian High Record!
            </div>
          ) : (
            <div className="text-xs text-neutral-500 font-code mt-2">
              Personal Best: {highScore.toLocaleString()}
            </div>
          )}
        </div>

        {/* Stats Grid */}
        <div className="p-6 grid grid-cols-2 sm:grid-cols-4 gap-3 bg-neutral-900/80">
          <div className="bg-neutral-950 border border-neutral-800 p-3 rounded text-center">
            <span className="text-[10px] text-neutral-400 uppercase font-code block">Waves Survived</span>
            <span className="text-xl font-heading font-bold text-neutral-100">{wave}</span>
          </div>

          <div className="bg-neutral-950 border border-neutral-800 p-3 rounded text-center">
            <span className="text-[10px] text-neutral-400 uppercase font-code block">Infected Slain</span>
            <span className="text-xl font-heading font-bold text-red-400">{stats.kills}</span>
          </div>

          <div className="bg-neutral-950 border border-neutral-800 p-3 rounded text-center">
            <span className="text-[10px] text-neutral-400 uppercase font-code block">Headshots</span>
            <span className="text-xl font-heading font-bold text-amber-400">{stats.headshots}</span>
          </div>

          <div className="bg-neutral-950 border border-neutral-800 p-3 rounded text-center">
            <span className="text-[10px] text-neutral-400 uppercase font-code block">Gun Accuracy</span>
            <span className="text-xl font-heading font-bold text-emerald-400">{accuracy}%</span>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="p-6 bg-neutral-950 border-t border-neutral-800 flex gap-4">
          <button
            id="gameover-home-btn"
            onClick={onHome}
            className="flex-1 py-3 px-4 bg-neutral-800 hover:bg-neutral-700 text-neutral-200 font-heading font-bold text-sm tracking-wider uppercase rounded transition flex items-center justify-center gap-2 cursor-pointer active:scale-95"
          >
            <Home className="w-4 h-4" />
            <span>Title Screen</span>
          </button>

          <button
            id="gameover-restart-btn"
            onClick={onRestart}
            className="flex-1 py-3 px-4 bg-red-700 hover:bg-red-600 text-white font-heading font-bold text-sm tracking-wider uppercase rounded transition flex items-center justify-center gap-2 cursor-pointer shadow-lg shadow-red-950 active:scale-95"
          >
            <RotateCcw className="w-4 h-4" />
            <span>Fight Again</span>
          </button>
        </div>
      </div>
    </div>
  );
};
