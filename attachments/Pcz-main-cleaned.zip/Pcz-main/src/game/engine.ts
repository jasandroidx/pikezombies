import { 
  Weapon, 
  Zombie, 
  Bullet, 
  Particle, 
  BloodDecal, 
  Drop, 
  FirePuddle, 
  AcidSpit, 
  GameLocation, 
  PlayerStats,
  Perk,
  ExplosiveBarrel,
  ActivePowerup,
  PowerupType,
  LoreNote
} from '../types/game';
import { INITIAL_WEAPONS, AVAILABLE_PERKS, GAME_LOCATIONS } from './constants';
import { soundEngine } from '../audio/soundEngine';
import { renderEnvironment } from './mapRenderer';
import { DynamicLighting } from './lighting';

export interface GameEngineCallbacks {
  onWaveComplete: (wave: number) => void;
  onGameOver: (stats: PlayerStats, score: number) => void;
  onLoreNoteFound?: (note: LoreNote) => void;
  onStatsUpdate: (stats: {
    health: number;
    maxHealth: number;
    stamina: number;
    weapon: Weapon;
    molotovs: number;
    score: number;
    scrap: number;
    combo: number;
    wave: number;
    waveTimer: number; // 0 if wave in progress
    zombiesRemaining: number;
    isReloading: boolean;
    reloadProgress: number;
    activePowerups: ActivePowerup[];
  }) => void;
}

export class GameEngine {
  public canvas: HTMLCanvasElement;
  public ctx: CanvasRenderingContext2D;
  private callbacks: GameEngineCallbacks;

  // Game state
  public isRunning: boolean = false;
  public isPaused: boolean = false;
  public currentLocation: GameLocation;
  public difficultyMultiplier: number = 1.0;

  // Player
  public player = {
    x: 1000,
    y: 900,
    radius: 18,
    speed: 3.4,
    health: 100,
    maxHealth: 100,
    stamina: 100,
    maxStamina: 100,
    isSprinting: false,
    angle: 0,
    flashlightRange: 420,
    flashlightAngle: 0,
    molotovs: 3,
    maxMolotovs: 5,
  };

  // Arsenal & Perks
  public weapons: Weapon[] = JSON.parse(JSON.stringify(INITIAL_WEAPONS));
  public currentWeaponIndex: number = 0;
  public perks: Perk[] = JSON.parse(JSON.stringify(AVAILABLE_PERKS));
  public scrap: number = 150;
  public score: number = 0;

  // Combat state
  private isMouseDown: boolean = false;
  private lastShotTime: number = 0;
  public isReloading: boolean = false;
  private reloadStartTime: number = 0;
  private muzzleFlashTimer: number = 0;
  private screenShake: number = 0;

  // Wave Manager
  public wave: number = 1;
  public waveState: 'active' | 'break' = 'break';
  public waveBreakCountdown: number = 8; // seconds
  private lastBreakTick: number = 0;
  private zombiesToSpawn: number = 0;
  private lastZombieSpawnTime: number = 0;

  // Entities
  public zombies: Zombie[] = [];
  public bullets: Bullet[] = [];
  public acidSpits: AcidSpit[] = [];
  public firePuddles: FirePuddle[] = [];
  public particles: Particle[] = [];
  public bloodDecals: BloodDecal[] = [];
  public drops: Drop[] = [];
  public explosiveBarrels: ExplosiveBarrel[] = [];
  public activePowerups: ActivePowerup[] = [];
  public loreNotes: LoreNote[] = [];

  // Lighting
  private lighting: DynamicLighting;

  // Combo
  public comboMultiplier: number = 1;
  private lastKillTime: number = 0;

  // Player Stats tracking
  public stats: PlayerStats = {
    kills: 0,
    headshots: 0,
    shotsFired: 0,
    shotsHit: 0,
    damageDealt: 0,
    damageTaken: 0,
    scrapCollected: 0,
    wavesCompleted: 0,
    survivalTime: 0,
  };
  private gameStartTime: number = 0;

  // Input
  public keys: { [key: string]: boolean } = {};
  public mousePos: { x: number; y: number } = { x: 0, y: 0 };
  public virtualJoystickMove: { x: number; y: number } = { x: 0, y: 0 };
  public virtualJoystickAim: { x: number; y: number } = { x: 0, y: 0 };

  private animationFrameId: number | null = null;
  private lastTimestamp: number = 0;

  constructor(canvas: HTMLCanvasElement, callbacks: GameEngineCallbacks, locationIndex: number = 0) {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d')!;
    this.callbacks = callbacks;
    this.currentLocation = GAME_LOCATIONS[locationIndex] || GAME_LOCATIONS[0];
    this.lighting = new DynamicLighting();

    this.player.x = this.currentLocation.mapWidth / 2;
    this.player.y = this.currentLocation.mapHeight / 2;

    this.initExplosiveBarrels();
    this.initLoreNotes();
    this.setupListeners();
  }

  public initLoreNotes() {
    this.loreNotes = [];
    if (this.currentLocation.loreNotes && this.currentLocation.loreNotes.length > 0) {
      this.loreNotes = this.currentLocation.loreNotes.map((note) => ({
        ...note,
        collected: false,
      }));
    }
  }

  public hasPowerup(type: PowerupType): boolean {
    return this.activePowerups.some((p) => p.type === type && p.durationRemaining > 0);
  }

  public activatePowerup(type: PowerupType) {
    soundEngine.playPowerup();

    // Instant effect: nuke wipes all current active zombies on map
    if (type === 'nuke') {
      this.detonateNuke();
      return;
    }

    // Timed effects (30,000 ms duration)
    const existing = this.activePowerups.find((p) => p.type === type);
    if (existing) {
      existing.durationRemaining = 30000;
      existing.totalDuration = 30000;
    } else {
      this.activePowerups.push({
        type,
        durationRemaining: 30000,
        totalDuration: 30000,
      });
    }

    // Instant boost if speed_boost
    if (type === 'speed_boost') {
      this.player.stamina = this.player.maxStamina;
    }
  }

  private detonateNuke() {
    soundEngine.playNuke();
    this.screenShake = 14;

    // Nuclear flash particle burst
    for (let i = 0; i < 60; i++) {
      const angle = Math.random() * Math.PI * 2;
      const dist = Math.random() * 500;
      this.particles.push({
        x: this.player.x + Math.cos(angle) * dist,
        y: this.player.y + Math.sin(angle) * dist,
        vx: (Math.random() - 0.5) * 12,
        vy: (Math.random() - 0.5) * 12,
        size: 5 + Math.random() * 8,
        color: Math.random() < 0.6 ? '#fde047' : '#f97316',
        alpha: 1,
        life: 0.8 + Math.random() * 0.4,
        maxLife: 1.2,
        type: 'fire',
      });
    }

    // Vaporize all zombies
    const killCount = this.zombies.length;
    for (let i = this.zombies.length - 1; i >= 0; i--) {
      const z = this.zombies[i];
      this.score += z.scoreValue;
      this.scrap += z.scrapValue;
      this.stats.kills++;

      // Blood spatter
      this.bloodDecals.push({
        x: z.x,
        y: z.y,
        radius: z.radius * 1.5,
        alpha: 0.8,
        rotation: Math.random() * Math.PI * 2,
      });
    }
    this.zombies = [];
  }

  private updatePowerups(dt: number) {
    const dtMs = dt * 1000;
    for (let i = this.activePowerups.length - 1; i >= 0; i--) {
      const p = this.activePowerups[i];
      p.durationRemaining -= dtMs;
      if (p.durationRemaining <= 0) {
        this.activePowerups.splice(i, 1);
      }
    }
  }

  public interactLoreNote() {
    // Find closest uncollected note within player interaction radius (65px)
    let closestNote: LoreNote | null = null;
    let closestDist = 65;

    for (const note of this.loreNotes) {
      if (note.collected) continue;
      const dist = Math.hypot(this.player.x - note.x, this.player.y - note.y);
      if (dist < closestDist) {
        closestDist = dist;
        closestNote = note;
      }
    }

    if (closestNote) {
      closestNote.collected = true;
      soundEngine.playLoreNote();
      this.score += 250; // Lore discovery bonus points
      this.scrap += 50;

      if (this.callbacks.onLoreNoteFound) {
        this.callbacks.onLoreNoteFound(closestNote);
      }
    }
  }

  public initExplosiveBarrels() {
    this.explosiveBarrels = [];
    if (this.currentLocation.barrels && this.currentLocation.barrels.length > 0) {
      this.explosiveBarrels = this.currentLocation.barrels.map((b, idx) => ({
        id: `barrel_${idx}_${Date.now()}`,
        x: b.x,
        y: b.y,
        radius: 18,
        health: 45,
        maxHealth: 45,
      }));
    }
  }

  private setupListeners() {
    window.addEventListener('keydown', this.handleKeyDown);
    window.addEventListener('keyup', this.handleKeyUp);
    this.canvas.addEventListener('mousemove', this.handleMouseMove);
    this.canvas.addEventListener('mousedown', this.handleMouseDown);
    window.addEventListener('mouseup', this.handleMouseUp);
    this.canvas.addEventListener('contextmenu', (e) => e.preventDefault());
    this.canvas.addEventListener('wheel', this.handleWheel, { passive: true });
  }

  public destroy() {
    this.stop();
    window.removeEventListener('keydown', this.handleKeyDown);
    window.removeEventListener('keyup', this.handleKeyUp);
    this.canvas.removeEventListener('mousemove', this.handleMouseMove);
    this.canvas.removeEventListener('mousedown', this.handleMouseDown);
    window.removeEventListener('mouseup', this.handleMouseUp);
    this.canvas.removeEventListener('wheel', this.handleWheel);
  }

  public start(difficultyMultiplier: number = 1.0) {
    this.difficultyMultiplier = difficultyMultiplier;
    this.isRunning = true;
    this.isPaused = false;
    this.gameStartTime = Date.now();
    this.lastTimestamp = performance.now();
    this.waveState = 'break';
    this.waveBreakCountdown = 5;
    this.lastBreakTick = Date.now();

    soundEngine.init();
    soundEngine.startAtmosphericMusic();

    this.loop(performance.now());
  }

  public stop() {
    this.isRunning = false;
    if (this.animationFrameId !== null) {
      cancelAnimationFrame(this.animationFrameId);
      this.animationFrameId = null;
    }
    soundEngine.stopAtmosphericMusic();
  }

  public setPaused(paused: boolean) {
    this.isPaused = paused;
    if (!paused && this.isRunning) {
      this.lastTimestamp = performance.now();
      this.loop(performance.now());
    }
  }

  // --- INPUT HANDLERS ---

  private handleKeyDown = (e: KeyboardEvent) => {
    this.keys[e.code] = true;

    if (e.code === 'KeyR') {
      this.reloadCurrentWeapon();
    }
    if (e.code === 'KeyE') {
      this.interactLoreNote();
    }
    if (e.code === 'Digit1') this.selectWeapon(0);
    if (e.code === 'Digit2') this.selectWeapon(1);
    if (e.code === 'Digit3') this.selectWeapon(2);
    if (e.code === 'Digit4') this.selectWeapon(3);
    if (e.code === 'Digit5') this.selectWeapon(4);
    if (e.code === 'Digit6') this.selectWeapon(5);

    // Space or Q to throw Molotov
    if (e.code === 'Space' || e.code === 'KeyQ') {
      this.throwMolotov();
    }
  };

  private handleKeyUp = (e: KeyboardEvent) => {
    this.keys[e.code] = false;
  };

  private handleMouseMove = (e: MouseEvent) => {
    const rect = this.canvas.getBoundingClientRect();
    this.mousePos.x = e.clientX - rect.left;
    this.mousePos.y = e.clientY - rect.top;
  };

  private handleMouseDown = (e: MouseEvent) => {
    if (e.button === 0) {
      this.isMouseDown = true;
    } else if (e.button === 2) {
      // Right click: throw Molotov
      e.preventDefault();
      this.throwMolotov();
    }
  };

  private handleMouseUp = () => {
    this.isMouseDown = false;
  };

  private handleWheel = (e: WheelEvent) => {
    if (e.deltaY > 0) {
      this.nextWeapon();
    } else if (e.deltaY < 0) {
      this.prevWeapon();
    }
  };

  public selectWeapon(index: number) {
    if (this.weapons[index] && this.weapons[index].unlocked) {
      this.currentWeaponIndex = index;
      this.isReloading = false;
    }
  }

  public nextWeapon() {
    let nextIdx = (this.currentWeaponIndex + 1) % this.weapons.length;
    while (!this.weapons[nextIdx].unlocked && nextIdx !== this.currentWeaponIndex) {
      nextIdx = (nextIdx + 1) % this.weapons.length;
    }
    this.selectWeapon(nextIdx);
  }

  public prevWeapon() {
    let prevIdx = (this.currentWeaponIndex - 1 + this.weapons.length) % this.weapons.length;
    while (!this.weapons[prevIdx].unlocked && prevIdx !== this.currentWeaponIndex) {
      prevIdx = (prevIdx - 1 + this.weapons.length) % this.weapons.length;
    }
    this.selectWeapon(prevIdx);
  }

  public reloadCurrentWeapon() {
    const weapon = this.weapons[this.currentWeaponIndex];
    if (
      !this.isReloading &&
      weapon.currentMag < weapon.magazineSize &&
      weapon.reserveAmmo > 0
    ) {
      this.isReloading = true;
      this.reloadStartTime = Date.now();
      soundEngine.playReload();
    }
  }

  public throwMolotov() {
    if (this.player.molotovs <= 0) return;
    this.player.molotovs--;

    const throwSpeed = 11;
    const bullet: Bullet = {
      id: Math.random().toString(),
      x: this.player.x,
      y: this.player.y,
      vx: Math.cos(this.player.angle) * throwSpeed,
      vy: Math.sin(this.player.angle) * throwSpeed,
      damage: 150,
      pierce: 1,
      rangeRemaining: 340,
      weaponType: 'molotov',
      isMolotov: true,
      radius: 6,
      color: '#f59e0b',
    };
    this.bullets.push(bullet);
    soundEngine.playGunshot('molotov');
  }

  public skipWaveBreak() {
    if (this.waveState === 'break') {
      this.waveBreakCountdown = 0;
    }
  }

  // --- MAIN LOOP ---

  private loop = (timestamp: number) => {
    if (!this.isRunning || this.isPaused) return;

    const dt = Math.min((timestamp - this.lastTimestamp) / 1000, 0.1);
    this.lastTimestamp = timestamp;

    this.update(dt);
    this.render();

    this.animationFrameId = requestAnimationFrame(this.loop);
  };

  // --- UPDATE LOGIC ---

  private update(dt: number) {
    const now = Date.now();

    // 0. Update Powerups Timers
    this.updatePowerups(dt);

    // 1. Update Player Movement & Sprinting
    this.updatePlayer(dt);

    // 2. Weapon Reloading & Firing
    this.updateWeapons(now);

    // 3. Bullets & Projectiles
    this.updateBullets(dt, now);

    // 4. Acid Spits from Bloater Spitters
    this.updateAcidSpits(dt);

    // 5. Fire Puddles
    this.updateFirePuddles(now);

    // 6. Wave Progress & Zombie Spawning
    this.updateWaveManager(now);

    // 7. Zombies AI & Movement
    this.updateZombies(dt, now);

    // 8. Drops Pickup check
    this.updateDrops();

    // 9. Particles
    this.updateParticles(dt);

    // 10. Combo decay
    if (now - this.lastKillTime > 4500 && this.comboMultiplier > 1) {
      this.comboMultiplier = 1;
    }

    // 11. Screen shake & muzzle decay
    if (this.screenShake > 0) this.screenShake = Math.max(0, this.screenShake - dt * 25);
    if (this.muzzleFlashTimer > 0) this.muzzleFlashTimer -= dt * 10;

    // 12. Send Stats to HUD
    const curWep = this.weapons[this.currentWeaponIndex];
    const reloadProg = this.isReloading
      ? Math.min(1, (now - this.reloadStartTime) / curWep.reloadTime)
      : 0;

    this.callbacks.onStatsUpdate({
      health: this.player.health,
      maxHealth: this.player.maxHealth,
      stamina: this.player.stamina,
      weapon: curWep,
      molotovs: this.player.molotovs,
      score: this.score,
      scrap: this.scrap,
      combo: this.comboMultiplier,
      wave: this.wave,
      waveTimer: this.waveState === 'break' ? this.waveBreakCountdown : 0,
      zombiesRemaining: this.zombies.length + this.zombiesToSpawn,
      isReloading: this.isReloading,
      reloadProgress: reloadProg,
      activePowerups: this.activePowerups,
    });
  }

  private updatePlayer(dt: number) {
    // Determine movement direction
    let dx = 0;
    let dy = 0;

    if (this.keys['KeyW'] || this.keys['ArrowUp']) dy -= 1;
    if (this.keys['KeyS'] || this.keys['ArrowDown']) dy += 1;
    if (this.keys['KeyA'] || this.keys['ArrowLeft']) dx -= 1;
    if (this.keys['KeyD'] || this.keys['ArrowRight']) dx += 1;

    // Virtual Joystick support
    if (this.virtualJoystickMove.x !== 0 || this.virtualJoystickMove.y !== 0) {
      dx = this.virtualJoystickMove.x;
      dy = this.virtualJoystickMove.y;
    }

    // Normalize
    const length = Math.hypot(dx, dy);
    if (length > 0) {
      dx /= length;
      dy /= length;
    }

    // Sprint check
    const hasSpeedBoost = this.hasPowerup('speed_boost');
    const wantsSprint = (this.keys['ShiftLeft'] || this.keys['ShiftRight']) && length > 0;
    if (wantsSprint && (this.player.stamina > 5 || hasSpeedBoost)) {
      this.player.isSprinting = true;
      if (!hasSpeedBoost) {
        this.player.stamina = Math.max(0, this.player.stamina - dt * 28);
      }
    } else {
      this.player.isSprinting = false;
      this.player.stamina = Math.min(this.player.maxStamina, this.player.stamina + dt * 18);
    }

    const speedMultiplier = (this.player.isSprinting ? 1.6 : 1.0) * (hasSpeedBoost ? 1.4 : 1.0);
    const currentSpeed = this.player.speed * speedMultiplier;
    const newX = this.player.x + dx * currentSpeed;
    const newY = this.player.y + dy * currentSpeed;

    // Collide with map obstacles
    if (!this.checkObstacleCollision(newX, this.player.y, this.player.radius)) {
      this.player.x = Math.max(this.player.radius, Math.min(this.currentLocation.mapWidth - this.player.radius, newX));
    }
    if (!this.checkObstacleCollision(this.player.x, newY, this.player.radius)) {
      this.player.y = Math.max(this.player.radius, Math.min(this.currentLocation.mapHeight - this.player.radius, newY));
    }

    // Aim angle towards mouse or virtual aim stick
    if (this.virtualJoystickAim.x !== 0 || this.virtualJoystickAim.y !== 0) {
      this.player.angle = Math.atan2(this.virtualJoystickAim.y, this.virtualJoystickAim.x);
    } else {
      const screenCenterX = this.canvas.width / 2;
      const screenCenterY = this.canvas.height / 2;
      this.player.angle = Math.atan2(
        this.mousePos.y - screenCenterY,
        this.mousePos.x - screenCenterX
      );
    }

    // Flashlight follows player angle with slight smoothing
    this.player.flashlightAngle = this.player.angle;
  }

  private updateWeapons(now: number) {
    const curWep = this.weapons[this.currentWeaponIndex];

    // Reload completion
    if (this.isReloading) {
      const perkQuick = this.getPerkLevel('quickdraw') * 0.2;
      const effectiveReloadTime = curWep.reloadTime * (1 - perkQuick);

      if (now - this.reloadStartTime >= effectiveReloadTime) {
        const needed = curWep.magazineSize - curWep.currentMag;
        const toLoad = Math.min(needed, curWep.reserveAmmo);
        curWep.currentMag += toLoad;
        curWep.reserveAmmo -= toLoad;
        this.isReloading = false;
      }
      return;
    }

    // Firing
    const hasInfiniteAmmo = this.hasPowerup('infinite_ammo');
    const fireRateBoost = hasInfiniteAmmo ? 1.4 : 1.0;
    const wantsFire = this.isMouseDown || (this.virtualJoystickAim.x !== 0 || this.virtualJoystickAim.y !== 0);
    const fireInterval = 1000 / (curWep.fireRate * (1 + this.getPerkLevel('quickdraw') * 0.18) * fireRateBoost);

    if (wantsFire && now - this.lastShotTime >= fireInterval) {
      if (curWep.currentMag > 0 || hasInfiniteAmmo) {
        this.fireCurrentWeapon();
        this.lastShotTime = now;
      } else {
        this.reloadCurrentWeapon();
      }
    }
  }

  private fireCurrentWeapon() {
    const curWep = this.weapons[this.currentWeaponIndex];
    if (!this.hasPowerup('infinite_ammo')) {
      curWep.currentMag--;
    }
    this.stats.shotsFired++;
    this.muzzleFlashTimer = 1.0;

    // Apply perks
    const extraDamage = 1 + this.getPerkLevel('hollowpoint') * 0.2;
    const chokeLevel = this.getPerkLevel('choke');
    const spreadMod = curWep.id === 'shotgun' ? Math.max(0.12, curWep.spread - chokeLevel * 0.05) : curWep.spread;
    const pelletsCount = curWep.id === 'shotgun' ? curWep.pellets + chokeLevel * 2 : curWep.pellets;

    // Screen recoil
    if (curWep.id === 'shotgun') this.screenShake = 6;
    else if (curWep.id === 'lever_rifle') this.screenShake = 4.5;
    else if (curWep.id === 'revolver') this.screenShake = 3;
    else if (curWep.id === 'chainsaw') this.screenShake = 1.2;

    soundEngine.playGunshot(curWep.soundType);

    // Spawn bullets/pellets
    for (let i = 0; i < pelletsCount; i++) {
      const angleOffset = (Math.random() - 0.5) * spreadMod;
      const bulletAngle = this.player.angle + angleOffset;
      const speed = curWep.bulletSpeed * (0.95 + Math.random() * 0.1);

      this.bullets.push({
        id: Math.random().toString(),
        x: this.player.x + Math.cos(this.player.angle) * 20,
        y: this.player.y + Math.sin(this.player.angle) * 20,
        vx: Math.cos(bulletAngle) * speed,
        vy: Math.sin(bulletAngle) * speed,
        damage: curWep.damage * extraDamage,
        pierce: curWep.pierce,
        rangeRemaining: curWep.range,
        weaponType: curWep.id,
        isCrossbowBolt: curWep.id === 'crossbow',
        radius: curWep.id === 'crossbow' ? 4 : curWep.id === 'shotgun' ? 3 : 3.5,
        color: curWep.id === 'crossbow' ? '#e2e8f0' : curWep.id === 'chainsaw' ? '#f59e0b' : '#fef08a',
      });
    }

    // Eject brass casing particle
    this.particles.push({
      x: this.player.x,
      y: this.player.y,
      vx: Math.cos(this.player.angle - Math.PI / 2) * (2 + Math.random() * 2),
      vy: Math.sin(this.player.angle - Math.PI / 2) * (2 + Math.random() * 2),
      size: 2.5,
      color: '#eab308',
      alpha: 1,
      life: 0.6,
      maxLife: 0.6,
      type: 'shell',
    });

    // Auto reload when dry
    if (curWep.currentMag === 0) {
      this.reloadCurrentWeapon();
    }
  }

  private updateBullets(dt: number, now: number) {
    for (let i = this.bullets.length - 1; i >= 0; i--) {
      const b = this.bullets[i];
      b.x += b.vx;
      b.y += b.vy;
      b.rangeRemaining -= Math.hypot(b.vx, b.vy);

      // Check obstacle collision (walls, cabins, trucks)
      if (this.checkObstacleCollision(b.x, b.y, b.radius, false)) {
        // Splinter sparks
        this.createHitSparks(b.x, b.y, '#f59e0b');
        this.bullets.splice(i, 1);
        continue;
      }

      // Check Explosive Barrels collision
      let barrelHit = false;
      for (let barIdx = this.explosiveBarrels.length - 1; barIdx >= 0; barIdx--) {
        const barrel = this.explosiveBarrels[barIdx];
        const distToBarrel = Math.hypot(barrel.x - b.x, barrel.y - b.y);
        if (distToBarrel <= barrel.radius + b.radius) {
          barrel.health -= b.damage;
          this.createHitSparks(b.x, b.y, '#ef4444');
          soundEngine.playZombieHit(false);

          if (barrel.health <= 0) {
            this.detonateExplosiveBarrel(barrel, barIdx);
          }
          this.bullets.splice(i, 1);
          barrelHit = true;
          break;
        }
      }
      if (barrelHit) continue;

      // Check Molotov impact
      if (b.isMolotov && b.rangeRemaining <= 0) {
        this.detonateMolotov(b.x, b.y);
        this.bullets.splice(i, 1);
        continue;
      }

      // Exceeded range
      if (b.rangeRemaining <= 0) {
        this.bullets.splice(i, 1);
        continue;
      }

      // Check Zombie Collisions
      for (let zIdx = this.zombies.length - 1; zIdx >= 0; zIdx--) {
        const z = this.zombies[zIdx];
        const dist = Math.hypot(z.x - b.x, z.y - b.y);

        if (dist <= z.radius + b.radius) {
          // Hit detected
          this.stats.shotsHit++;
          const isHeadshot = this.checkHeadshot(b, z);

          let finalDamage = b.damage;
          if (this.hasPowerup('insta_kill')) {
            finalDamage = 99999;
          } else if (isHeadshot) {
            if (z.hasHelmet) {
              // Coal miner helmet absorbs the headshot
              z.hasHelmet = false;
              this.createHitSparks(z.x, z.y, '#eab308');
              soundEngine.playZombieHit(false);
              finalDamage *= 0.6;
            } else {
              finalDamage *= 2.4;
              this.stats.headshots++;
              soundEngine.playZombieHit(true);
            }
          } else {
            soundEngine.playZombieHit(false);
          }

          z.health -= finalDamage;
          this.stats.damageDealt += finalDamage;

          // Knockback
          const knockAngle = Math.atan2(b.vy, b.vx);
          const knockForce = b.weaponType === 'shotgun' ? 7 : 3;
          z.x += Math.cos(knockAngle) * knockForce;
          z.y += Math.sin(knockAngle) * knockForce;

          // Blood particles
          this.createBloodParticles(b.x, b.y, knockAngle);

          // Pierce decrement
          b.pierce--;
          if (b.pierce <= 0) {
            this.bullets.splice(i, 1);
            break;
          }
        }
      }
    }
  }

  private checkHeadshot(bullet: Bullet, zombie: Zombie): boolean {
    // Vector from zombie to bullet
    const angleToBullet = Math.atan2(bullet.y - zombie.y, bullet.x - zombie.x);
    const angleDiff = Math.abs(this.normalizeAngle(angleToBullet - zombie.angle));
    // Facing forward headshot or close center snipe
    return angleDiff < 0.7;
  }

  private normalizeAngle(angle: number): number {
    while (angle > Math.PI) angle -= Math.PI * 2;
    while (angle < -Math.PI) angle += Math.PI * 2;
    return angle;
  }

  private detonateMolotov(x: number, y: number) {
    const perkRadius = 1 + this.getPerkLevel('moonshiner') * 0.4;
    const radius = 95 * perkRadius;
    const duration = 6000 + this.getPerkLevel('moonshiner') * 2500;

    this.firePuddles.push({
      id: Math.random().toString(),
      x,
      y,
      radius,
      duration,
      createdTime: Date.now(),
    });

    this.screenShake = 5;
    soundEngine.playBottleShatter();

    // Damage all zombies in initial blast
    for (const z of this.zombies) {
      if (Math.hypot(z.x - x, z.y - y) <= radius) {
        z.health -= 120;
        z.isBurning = 4000;
      }
    }
  }

  public detonateExplosiveBarrel(barrel: ExplosiveBarrel, index: number) {
    this.explosiveBarrels.splice(index, 1);

    const blastRadius = 140;
    const blastDamage = 350;

    this.screenShake = 10;
    soundEngine.playBarrelExplosion();

    // Spawn explosion fire puddle
    this.firePuddles.push({
      id: Math.random().toString(),
      x: barrel.x,
      y: barrel.y,
      radius: blastRadius * 0.75,
      duration: 5000,
      createdTime: Date.now(),
    });

    // Spawn burst of fire and smoke particles
    for (let i = 0; i < 35; i++) {
      const angle = Math.random() * Math.PI * 2;
      const speed = 2 + Math.random() * 6;
      this.particles.push({
        x: barrel.x,
        y: barrel.y,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed,
        size: 3 + Math.random() * 5,
        color: Math.random() < 0.6 ? '#ef4444' : Math.random() < 0.5 ? '#f97316' : '#78350f',
        alpha: 1,
        life: 0.4 + Math.random() * 0.4,
        maxLife: 0.8,
        type: 'smoke',
      });
    }

    // Damage nearby zombies
    for (let i = this.zombies.length - 1; i >= 0; i--) {
      const z = this.zombies[i];
      const dist = Math.hypot(z.x - barrel.x, z.y - barrel.y);
      if (dist <= blastRadius) {
        const falloff = 1 - dist / blastRadius;
        const damage = blastDamage * (0.4 + falloff * 0.6);
        z.health -= damage;
        z.isBurning = 4000;

        // Knockback from blast
        const knockAngle = Math.atan2(z.y - barrel.y, z.x - barrel.x);
        z.x += Math.cos(knockAngle) * (18 * falloff);
        z.y += Math.sin(knockAngle) * (18 * falloff);

        this.stats.damageDealt += damage;
        this.createBloodParticles(z.x, z.y, knockAngle);

        if (z.health <= 0) {
          this.killZombie(z, i);
        }
      }
    }

    // Damage player if too close to the barrel
    const distToPlayer = Math.hypot(this.player.x - barrel.x, this.player.y - barrel.y);
    if (distToPlayer <= blastRadius) {
      const playerFalloff = 1 - distToPlayer / blastRadius;
      this.damagePlayer(Math.round(45 * playerFalloff));
    }

    // Chain reaction with nearby explosive barrels!
    for (let j = this.explosiveBarrels.length - 1; j >= 0; j--) {
      const other = this.explosiveBarrels[j];
      const distToOther = Math.hypot(other.x - barrel.x, other.y - barrel.y);
      if (distToOther <= blastRadius) {
        other.health -= 250;
        if (other.health <= 0) {
          setTimeout(() => {
            const currentIdx = this.explosiveBarrels.indexOf(other);
            if (currentIdx !== -1) {
              this.detonateExplosiveBarrel(other, currentIdx);
            }
          }, 120);
        }
      }
    }
  }

  private updateFirePuddles(now: number) {
    for (let i = this.firePuddles.length - 1; i >= 0; i--) {
      const p = this.firePuddles[i];
      const elapsed = now - p.createdTime;
      if (elapsed >= p.duration) {
        this.firePuddles.splice(i, 1);
        continue;
      }

      // Burn zombies standing in pool
      for (const z of this.zombies) {
        if (Math.hypot(z.x - p.x, z.y - p.y) <= p.radius) {
          z.health -= 0.9;
          z.isBurning = 3000;
        }
      }

      // Burn player if standing in pool
      if (Math.hypot(this.player.x - p.x, this.player.y - p.y) <= p.radius) {
        this.damagePlayer(0.3);
      }
    }
  }

  private updateAcidSpits(dt: number) {
    for (let i = this.acidSpits.length - 1; i >= 0; i--) {
      const spit = this.acidSpits[i];
      spit.x += spit.vx;
      spit.y += spit.vy;
      spit.remainingDistance -= Math.hypot(spit.vx, spit.vy);

      // Check collision with player
      if (Math.hypot(this.player.x - spit.x, this.player.y - spit.y) <= this.player.radius + spit.radius) {
        this.damagePlayer(spit.damage);
        this.createHitSparks(spit.x, spit.y, '#84cc16');
        this.acidSpits.splice(i, 1);
        continue;
      }

      if (spit.remainingDistance <= 0 || this.checkObstacleCollision(spit.x, spit.y, spit.radius)) {
        this.createHitSparks(spit.x, spit.y, '#84cc16');
        this.acidSpits.splice(i, 1);
      }
    }
  }

  private updateWaveManager(now: number) {
    if (this.waveState === 'break') {
      if (now - this.lastBreakTick >= 1000) {
        this.lastBreakTick = now;
        this.waveBreakCountdown--;
        if (this.waveBreakCountdown <= 0) {
          this.startNextWave();
        }
      }
      return;
    }

    // Active wave
    // Spawn remaining zombies
    if (this.zombiesToSpawn > 0 && now - this.lastZombieSpawnTime > 750) {
      this.spawnRandomZombie();
      this.zombiesToSpawn--;
      this.lastZombieSpawnTime = now;
    }

    // Check if wave is cleared
    if (this.zombiesToSpawn === 0 && this.zombies.length === 0) {
      this.waveState = 'break';
      this.waveBreakCountdown = 10;
      this.stats.wavesCompleted++;
      this.scrap += 120 + this.wave * 25; // wave bonus
      this.callbacks.onWaveComplete(this.wave);
      soundEngine.playWaveHorn();
    }
  }

  private startNextWave() {
    this.wave++;
    this.waveState = 'active';

    // Base zombie count increases each wave
    const count = Math.floor((10 + this.wave * 4.5) * this.difficultyMultiplier);
    this.zombiesToSpawn = count;

    soundEngine.playWaveHorn();
  }

  private spawnRandomZombie() {
    // Pick spawn location outside camera viewport / near map perimeter
    const margin = 50;
    let spawnX = 0;
    let spawnY = 0;
    const edge = Math.floor(Math.random() * 4);

    if (edge === 0) {
      spawnX = margin + Math.random() * (this.currentLocation.mapWidth - margin * 2);
      spawnY = margin;
    } else if (edge === 1) {
      spawnX = margin + Math.random() * (this.currentLocation.mapWidth - margin * 2);
      spawnY = this.currentLocation.mapHeight - margin;
    } else if (edge === 2) {
      spawnX = margin;
      spawnY = margin + Math.random() * (this.currentLocation.mapHeight - margin * 2);
    } else {
      spawnX = this.currentLocation.mapWidth - margin;
      spawnY = margin + Math.random() * (this.currentLocation.mapHeight - margin * 2);
    }

    // Determine zombie type based on wave
    let type: Zombie['type'] = 'shambler';
    const roll = Math.random();

    if (this.wave >= 5 && this.wave % 5 === 0 && this.zombiesToSpawn === 1) {
      type = 'behemoth'; // Boss wave!
    } else if (this.wave >= 4 && roll < 0.2) {
      type = 'bloater_spitter';
    } else if (this.wave >= 3 && roll < 0.45) {
      type = 'miner_brute';
    } else if (this.wave >= 2 && roll < 0.7) {
      type = 'sprinter';
    }

    let maxHealth = 70;
    let speed = 1.35;
    let damage = 14;
    let radius = 17;
    let color = '#475569';
    let hasHelmet = false;
    let scoreValue = 100;
    let scrapValue = 15;

    if (type === 'sprinter') {
      maxHealth = 45;
      speed = 3.3;
      damage = 10;
      radius = 15;
      color = '#991b1b';
      scoreValue = 140;
      scrapValue = 20;
    } else if (type === 'miner_brute') {
      maxHealth = 220;
      speed = 1.1;
      damage = 25;
      radius = 23;
      color = '#1e293b';
      hasHelmet = true;
      scoreValue = 250;
      scrapValue = 40;
    } else if (type === 'bloater_spitter') {
      maxHealth = 130;
      speed = 1.0;
      damage = 18;
      radius = 21;
      color = '#65a30d';
      scoreValue = 220;
      scrapValue = 35;
    } else if (type === 'behemoth') {
      maxHealth = 1400 + this.wave * 250;
      speed = 1.6;
      damage = 45;
      radius = 38;
      color = '#581c87';
      scoreValue = 1500;
      scrapValue = 250;
    }

    const zombie: Zombie = {
      id: Math.random().toString(),
      type,
      x: spawnX,
      y: spawnY,
      vx: 0,
      vy: 0,
      angle: 0,
      speed: speed * (0.9 + Math.random() * 0.2),
      maxHealth,
      health: maxHealth,
      damage,
      attackCooldown: 900,
      lastAttackTime: 0,
      radius,
      color,
      hasHelmet,
      animationFrame: 0,
      scoreValue,
      scrapValue,
      spitCooldown: 2500,
    };

    this.zombies.push(zombie);
    soundEngine.playZombieGroan(type);
  }

  private updateZombies(dt: number, now: number) {
    for (let i = this.zombies.length - 1; i >= 0; i--) {
      const z = this.zombies[i];

      // Burning damage
      if (z.isBurning && z.isBurning > 0) {
        z.isBurning -= dt * 1000;
        z.health -= dt * 35;
        // Fire particles on zombie
        if (Math.random() < 0.3) {
          this.particles.push({
            x: z.x + (Math.random() - 0.5) * z.radius,
            y: z.y + (Math.random() - 0.5) * z.radius,
            vx: (Math.random() - 0.5) * 1.5,
            vy: -1.5 - Math.random() * 2,
            size: 3,
            color: '#f97316',
            alpha: 0.9,
            life: 0.4,
            maxLife: 0.4,
            type: 'fire',
          });
        }
      }

      // Check death
      if (z.health <= 0) {
        this.killZombie(z, i);
        continue;
      }

      // Distance to player
      const dx = this.player.x - z.x;
      const dy = this.player.y - z.y;
      const distToPlayer = Math.hypot(dx, dy);

      // Angle to player
      z.angle = Math.atan2(dy, dx);

      // Bloater Spitter ranged attack
      if (z.type === 'bloater_spitter') {
        if (!z.spitCooldown) z.spitCooldown = 2500;
        z.spitCooldown -= dt * 1000;

        if (z.spitCooldown <= 0 && distToPlayer < 450) {
          z.spitCooldown = 3200;
          const spitSpeed = 7;
          this.acidSpits.push({
            id: Math.random().toString(),
            x: z.x,
            y: z.y,
            vx: Math.cos(z.angle) * spitSpeed,
            vy: Math.sin(z.angle) * spitSpeed,
            radius: 7,
            damage: 22,
            remainingDistance: 450,
          });
          soundEngine.playZombieHit(false);
        }
      }

      // Path toward player with obstacle sliding
      let moveSpeed = z.speed;
      if (z.type === 'behemoth' && z.health < z.maxHealth * 0.4) {
        moveSpeed *= 1.4; // Enraged boss charge
      }

      const stepX = Math.cos(z.angle) * moveSpeed;
      const stepY = Math.sin(z.angle) * moveSpeed;

      const targetX = z.x + stepX;
      const targetY = z.y + stepY;

      if (!this.checkObstacleCollision(targetX, z.y, z.radius)) {
        z.x = targetX;
      }
      if (!this.checkObstacleCollision(z.x, targetY, z.radius)) {
        z.y = targetY;
      }

      // Zombie crowding avoidance
      for (let j = 0; j < this.zombies.length; j++) {
        if (i === j) continue;
        const other = this.zombies[j];
        const sepX = z.x - other.x;
        const sepY = z.y - other.y;
        const sepDist = Math.hypot(sepX, sepY);
        const minSep = z.radius + other.radius;
        if (sepDist < minSep && sepDist > 0) {
          const push = (minSep - sepDist) * 0.15;
          z.x += (sepX / sepDist) * push;
          z.y += (sepY / sepDist) * push;
        }
      }

      // Attack player on contact
      if (distToPlayer <= z.radius + this.player.radius) {
        if (now - z.lastAttackTime >= z.attackCooldown) {
          this.damagePlayer(z.damage);
          z.lastAttackTime = now;
        }
      }
    }
  }

  private killZombie(z: Zombie, index: number) {
    this.zombies.splice(index, 1);
    this.stats.kills++;
    this.lastKillTime = Date.now();
    this.comboMultiplier = Math.min(5, this.comboMultiplier + 0.25);

    const doubleMult = this.hasPowerup('double_points') ? 2 : 1;
    const points = Math.round(z.scoreValue * this.comboMultiplier * doubleMult);
    this.score += points;

    // Drop scrap currency
    const scavengerLevel = this.getPerkLevel('scavenger');
    const scrapBonus = 1 + scavengerLevel * 0.35;
    this.scrap += Math.round(z.scrapValue * scrapBonus * doubleMult);

    // Leave blood decal on the ground
    this.bloodDecals.push({
      x: z.x,
      y: z.y,
      radius: z.radius * (1.2 + Math.random() * 0.6),
      alpha: 0.65 + Math.random() * 0.25,
      rotation: Math.random() * Math.PI * 2,
    });
    // Keep max 150 decals for performance
    if (this.bloodDecals.length > 150) this.bloodDecals.shift();

    // Check for rare tactical Powerup Drop (4% chance)
    if (Math.random() < 0.04) {
      const powerupTypes: PowerupType[] = ['nuke', 'double_points', 'insta_kill', 'infinite_ammo', 'speed_boost'];
      const chosenPowerup = powerupTypes[Math.floor(Math.random() * powerupTypes.length)];
      this.drops.push({
        id: Math.random().toString(),
        type: chosenPowerup,
        x: z.x,
        y: z.y,
        amount: 1,
        duration: 30000,
      });
      return;
    }

    // Random items drop (Ammo or Moonshine or Molotov)
    const dropChance = 0.32 + scavengerLevel * 0.1;
    if (Math.random() < dropChance) {
      const dropRoll = Math.random();
      let dropType: Drop['type'] = 'ammo_universal';
      let amount = 15;

      if (dropRoll < 0.35 && this.player.health < this.player.maxHealth) {
        dropType = 'moonshine_med';
        amount = 35;
      } else if (dropRoll < 0.55) {
        dropType = 'molotov_pickup';
        amount = 1;
      } else if (dropRoll < 0.75) {
        dropType = 'scrap';
        amount = 25;
      }

      this.drops.push({
        id: Math.random().toString(),
        type: dropType,
        x: z.x,
        y: z.y,
        amount,
        duration: 25000,
      });
    }
  }

  private damagePlayer(amount: number) {
    // Appalachian Grit reduces damage taken
    const gritReduction = this.getPerkLevel('grit') * 0.08;
    const finalDamage = amount * (1 - gritReduction);

    this.player.health -= finalDamage;
    this.stats.damageTaken += finalDamage;
    this.screenShake = 7;
    soundEngine.playPlayerHurt();

    if (this.player.health <= 0) {
      this.player.health = 0;
      this.handleGameOver();
    }
  }

  private handleGameOver() {
    this.isRunning = false;
    this.stats.survivalTime = Math.floor((Date.now() - this.gameStartTime) / 1000);
    this.callbacks.onGameOver(this.stats, this.score);
  }

  private updateDrops() {
    for (let i = this.drops.length - 1; i >= 0; i--) {
      const d = this.drops[i];
      const dist = Math.hypot(this.player.x - d.x, this.player.y - d.y);

      if (dist <= this.player.radius + 18) {
        // Collect drop
        soundEngine.playPickup();

        if (d.type === 'ammo_universal') {
          // Replenish all unlocked weapons reserve ammo
          for (const w of this.weapons) {
            if (w.unlocked) {
              w.reserveAmmo = Math.min(w.maxReserveAmmo, w.reserveAmmo + Math.floor(w.magazineSize * 1.5));
            }
          }
        } else if (d.type === 'moonshine_med') {
          this.player.health = Math.min(this.player.maxHealth, this.player.health + d.amount);
          // Adrenaline boost: replenish stamina
          this.player.stamina = this.player.maxStamina;
        } else if (d.type === 'molotov_pickup') {
          this.player.molotovs = Math.min(this.player.maxMolotovs, this.player.molotovs + 1);
        } else if (d.type === 'scrap') {
          this.scrap += d.amount;
        } else if (
          d.type === 'nuke' ||
          d.type === 'insta_kill' ||
          d.type === 'double_points' ||
          d.type === 'infinite_ammo' ||
          d.type === 'speed_boost'
        ) {
          this.activatePowerup(d.type);
        }

        this.drops.splice(i, 1);
      }
    }
  }

  private updateParticles(dt: number) {
    for (let i = this.particles.length - 1; i >= 0; i--) {
      const p = this.particles[i];
      p.x += p.vx;
      p.y += p.vy;
      p.life -= dt;
      p.alpha = Math.max(0, p.life / p.maxLife);

      if (p.life <= 0) {
        this.particles.splice(i, 1);
      }
    }
  }

  private createBloodParticles(x: number, y: number, impactAngle: number) {
    for (let i = 0; i < 7; i++) {
      const angle = impactAngle + (Math.random() - 0.5) * 1.2;
      const speed = 2 + Math.random() * 4;
      this.particles.push({
        x,
        y,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed,
        size: 2.5 + Math.random() * 3.5,
        color: Math.random() < 0.7 ? '#880808' : '#550000',
        alpha: 1,
        life: 0.35 + Math.random() * 0.25,
        maxLife: 0.5,
        type: 'blood',
      });
    }
  }

  private createHitSparks(x: number, y: number, color: string) {
    for (let i = 0; i < 6; i++) {
      const angle = Math.random() * Math.PI * 2;
      const speed = 1.5 + Math.random() * 3.5;
      this.particles.push({
        x,
        y,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed,
        size: 2,
        color,
        alpha: 1,
        life: 0.2 + Math.random() * 0.15,
        maxLife: 0.3,
        type: 'spark',
      });
    }
  }

  private checkObstacleCollision(x: number, y: number, radius: number, includeBarrels: boolean = true): boolean {
    for (const obs of this.currentLocation.obstacles) {
      if (
        x + radius > obs.x &&
        x - radius < obs.x + obs.width &&
        y + radius > obs.y &&
        y - radius < obs.y + obs.height
      ) {
        return true;
      }
    }

    // Also collide with intact explosive barrels
    if (includeBarrels) {
      for (const barrel of this.explosiveBarrels) {
        const dist = Math.hypot(x - barrel.x, y - barrel.y);
        if (dist < radius + barrel.radius) {
          return true;
        }
      }
    }

    return false;
  }

  public getPerkLevel(perkId: string): number {
    const perk = this.perks.find((p) => p.id === perkId);
    return perk ? perk.level : 0;
  }

  // --- RENDER ---

  private render() {
    const ctx = this.ctx;
    const w = this.canvas.width;
    const h = this.canvas.height;

    ctx.save();
    ctx.clearRect(0, 0, w, h);

    // Apply Screen Shake
    if (this.screenShake > 0) {
      const shakeX = (Math.random() - 0.5) * this.screenShake;
      const shakeY = (Math.random() - 0.5) * this.screenShake;
      ctx.translate(shakeX, shakeY);
    }

    // Camera follow player: center player on screen
    const camX = this.player.x - w / 2;
    const camY = this.player.y - h / 2;

    ctx.save();
    ctx.translate(-camX, -camY);

    const viewport = { x: camX, y: camY, width: w, height: h };

    // 1. Render Map Environment (Ground, trees, cabins, trucks, blood decals, drops, fire, barrels, lore notes)
    renderEnvironment(
      ctx,
      this.currentLocation,
      viewport,
      this.bloodDecals,
      this.firePuddles,
      this.drops,
      this.explosiveBarrels,
      this.loreNotes
    );

    // 2. Render Zombies
    this.renderZombies(ctx);

    // 3. Render Player
    this.renderPlayer(ctx);

    // 4. Render Bullets & Acid Spits
    this.renderProjectiles(ctx);

    // 5. Render Particles
    this.renderParticles(ctx);

    ctx.restore(); // restore camera translation

    // 6. Dynamic Lighting & Darkness Mask (drawn relative to screen)
    const screenPlayer = {
      x: w / 2,
      y: h / 2,
      angle: this.player.angle,
      flashlightAngle: this.player.flashlightAngle,
      flashlightRange: this.player.flashlightRange * (1 + this.getPerkLevel('highbeam') * 0.25),
    };

    // Convert fire puddles and static lights to screen coordinates
    const screenFires = this.firePuddles.map((f) => ({
      ...f,
      x: f.x - camX,
      y: f.y - camY,
    }));

    const staticLights = [
      // Cabin windows
      { x: 920 + 25 - camX, y: 760 + 20 - camY, radius: 90, intensity: 0.8 },
      { x: 920 + 220 - 49 - camX, y: 760 + 20 - camY, radius: 90, intensity: 0.8 },
    ];

    this.lighting.renderLighting(
      ctx,
      w,
      h,
      screenPlayer,
      this.muzzleFlashTimer,
      this.currentLocation.ambientLight,
      screenFires,
      staticLights
    );

    // 7. Check if player is near any uncollected Lore Note and draw an interaction prompt
    const nearbyNote = this.loreNotes.find((n) => !n.collected && Math.hypot(this.player.x - n.x, this.player.y - n.y) < 65);
    if (nearbyNote) {
      ctx.save();
      const promptX = w / 2;
      const promptY = h / 2 - 42;

      ctx.fillStyle = 'rgba(15, 23, 42, 0.85)';
      ctx.strokeStyle = '#f59e0b';
      ctx.lineWidth = 1.5;
      const boxW = 190;
      const boxH = 32;
      ctx.beginPath();
      ctx.roundRect(promptX - boxW / 2, promptY - boxH / 2, boxW, boxH, 6);
      ctx.fill();
      ctx.stroke();

      ctx.fillStyle = '#f59e0b';
      ctx.font = 'bold 12px sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(`Press [E] to read Note`, promptX, promptY);
      ctx.restore();
    }

    ctx.restore();
  }

  private renderPlayer(ctx: CanvasRenderingContext2D) {
    ctx.save();
    ctx.translate(this.player.x, this.player.y);
    ctx.rotate(this.player.angle);

    // Flashlight casing on shoulder
    ctx.fillStyle = '#1e293b';
    ctx.fillRect(8, -12, 16, 6);
    ctx.fillStyle = '#e2e8f0';
    ctx.fillRect(22, -13, 3, 8);

    // Player body (Appalachian flannel jacket)
    ctx.fillStyle = '#7c2d12'; // Flannel red/brown
    ctx.beginPath();
    ctx.arc(0, 0, this.player.radius, 0, Math.PI * 2);
    ctx.fill();

    // Shoulders
    ctx.fillStyle = '#451a03';
    ctx.beginPath();
    ctx.arc(0, 0, this.player.radius * 0.7, 0, Math.PI * 2);
    ctx.fill();

    // Hunting Cap / Beanie
    ctx.fillStyle = '#14532d'; // Dark hunter green
    ctx.beginPath();
    ctx.arc(-2, 0, 9, 0, Math.PI * 2);
    ctx.fill();

    // Hands and Weapon
    const curWep = this.weapons[this.currentWeaponIndex];
    ctx.fillStyle = '#475569';

    if (curWep.id === 'chainsaw') {
      // Big yellow logging chainsaw
      ctx.fillStyle = '#eab308';
      ctx.fillRect(8, -6, 26, 12);
      ctx.fillStyle = '#64748b'; // blade bar
      ctx.fillRect(34, -4, 28, 8);
      // Saw teeth
      ctx.fillStyle = '#ffffff';
      for (let x = 36; x < 60; x += 4) {
        ctx.fillRect(x, -6, 2, 2);
        ctx.fillRect(x, 4, 2, 2);
      }
    } else if (curWep.id === 'shotgun') {
      // Pump shotgun barrel & wooden stock
      ctx.fillStyle = '#78350f';
      ctx.fillRect(4, -3, 14, 6);
      ctx.fillStyle = '#1e293b';
      ctx.fillRect(18, -2, 24, 4);
    } else if (curWep.id === 'lever_rifle') {
      // Long rifle barrel
      ctx.fillStyle = '#451a03';
      ctx.fillRect(4, -2, 12, 5);
      ctx.fillStyle = '#0f172a';
      ctx.fillRect(16, -1.5, 30, 3);
    } else if (curWep.id === 'crossbow') {
      // Crossbow frame and bow arms
      ctx.fillStyle = '#334155';
      ctx.fillRect(6, -3, 22, 6);
      ctx.strokeStyle = '#64748b';
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.moveTo(24, -18);
      ctx.quadraticCurveTo(16, 0, 24, 18);
      ctx.stroke();
    } else {
      // Handgun / Revolver
      ctx.fillStyle = '#1e293b';
      ctx.fillRect(10, 2, 16, 4);
    }

    // Hands
    ctx.fillStyle = '#d97706';
    ctx.beginPath();
    ctx.arc(14, 7, 4, 0, Math.PI * 2);
    ctx.arc(14, -7, 4, 0, Math.PI * 2);
    ctx.fill();

    ctx.restore();
  }

  private renderZombies(ctx: CanvasRenderingContext2D) {
    for (const z of this.zombies) {
      ctx.save();
      ctx.translate(z.x, z.y);
      ctx.rotate(z.angle);

      // Zombie shadow
      ctx.fillStyle = 'rgba(0, 0, 0, 0.4)';
      ctx.beginPath();
      ctx.ellipse(0, 0, z.radius * 1.1, z.radius * 0.8, 0, 0, Math.PI * 2);
      ctx.fill();

      // Body
      ctx.fillStyle = z.color;
      ctx.beginPath();
      ctx.arc(0, 0, z.radius, 0, Math.PI * 2);
      ctx.fill();

      // Arms reaching out
      ctx.fillStyle = '#334155';
      ctx.fillRect(z.radius * 0.5, -z.radius * 0.7, z.radius * 0.9, 5);
      ctx.fillRect(z.radius * 0.5, z.radius * 0.4, z.radius * 0.9, 5);

      // Decayed hands
      ctx.fillStyle = '#1e293b';
      ctx.beginPath();
      ctx.arc(z.radius * 1.4, -z.radius * 0.6, 3, 0, Math.PI * 2);
      ctx.arc(z.radius * 1.4, z.radius * 0.5, 3, 0, Math.PI * 2);
      ctx.fill();

      // Coal Miner hardhat with headlamp
      if (z.type === 'miner_brute') {
        if (z.hasHelmet) {
          ctx.fillStyle = '#eab308'; // yellow hardhat
          ctx.beginPath();
          ctx.arc(0, 0, z.radius * 0.85, 0, Math.PI * 2);
          ctx.fill();

          // Working headlamp beam
          ctx.fillStyle = 'rgba(254, 240, 138, 0.85)';
          ctx.beginPath();
          ctx.arc(z.radius * 0.75, 0, 5, 0, Math.PI * 2);
          ctx.fill();
        }
      }

      // Behemoth spikes / bulk
      if (z.type === 'behemoth') {
        ctx.fillStyle = '#3b0764';
        for (let a = 0; a < Math.PI * 2; a += Math.PI / 4) {
          ctx.beginPath();
          ctx.arc(Math.cos(a) * z.radius, Math.sin(a) * z.radius, 6, 0, Math.PI * 2);
          ctx.fill();
        }
      }

      // Burning visual overlay
      if (z.isBurning && z.isBurning > 0) {
        ctx.fillStyle = 'rgba(249, 115, 22, 0.4)';
        ctx.beginPath();
        ctx.arc(0, 0, z.radius * 1.2, 0, Math.PI * 2);
        ctx.fill();
      }

      // Health bar above head (for tanky or damaged zombies)
      if (z.health < z.maxHealth || z.type === 'miner_brute' || z.type === 'behemoth') {
        const barW = z.radius * 2.2;
        const barH = 4;
        const hpRatio = Math.max(0, z.health / z.maxHealth);

        ctx.fillStyle = 'rgba(0, 0, 0, 0.7)';
        ctx.fillRect(-barW / 2, -z.radius - 12, barW, barH);

        ctx.fillStyle = z.type === 'behemoth' ? '#a855f7' : '#ef4444';
        ctx.fillRect(-barW / 2, -z.radius - 12, barW * hpRatio, barH);
      }

      ctx.restore();
    }
  }

  private renderProjectiles(ctx: CanvasRenderingContext2D) {
    // Bullets
    for (const b of this.bullets) {
      ctx.save();
      ctx.translate(b.x, b.y);

      if (b.isMolotov) {
        // Rotating Molotov glass bottle with burning wick
        ctx.fillStyle = '#f59e0b';
        ctx.fillRect(-3, -6, 6, 12);
        ctx.fillStyle = '#ef4444';
        ctx.beginPath();
        ctx.arc(0, -8, 3, 0, Math.PI * 2);
        ctx.fill();
      } else if (b.isCrossbowBolt) {
        const boltAngle = Math.atan2(b.vy, b.vx);
        ctx.rotate(boltAngle);
        ctx.fillStyle = '#94a3b8';
        ctx.fillRect(-8, -1, 16, 2);
        ctx.fillStyle = '#e2e8f0'; // arrow fletching
        ctx.fillRect(-8, -3, 3, 6);
      } else {
        // High-velocity bullet tracer
        const bulletAngle = Math.atan2(b.vy, b.vx);
        ctx.rotate(bulletAngle);
        ctx.fillStyle = b.color;
        ctx.fillRect(-6, -b.radius / 2, 12, b.radius);
      }

      ctx.restore();
    }

    // Acid Spits
    for (const spit of this.acidSpits) {
      ctx.fillStyle = '#84cc16';
      ctx.beginPath();
      ctx.arc(spit.x, spit.y, spit.radius, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  private renderParticles(ctx: CanvasRenderingContext2D) {
    for (const p of this.particles) {
      ctx.save();
      ctx.globalAlpha = p.alpha;
      ctx.fillStyle = p.color;
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    }
  }
}
