export type WeaponType = 
  | 'revolver'
  | 'shotgun'
  | 'lever_rifle'
  | 'carbine'
  | 'crossbow'
  | 'chainsaw'
  | 'molotov';

export interface Weapon {
  id: WeaponType;
  name: string;
  category: string;
  description: string;
  damage: number;
  fireRate: number; // shots per second
  pellets: number;
  spread: number; // in radians
  range: number;
  bulletSpeed: number;
  magazineSize: number;
  currentMag: number;
  reserveAmmo: number;
  maxReserveAmmo: number;
  reloadTime: number; // in ms
  pierce: number;
  soundType: 'magnum' | 'shotgun' | 'rifle' | 'carbine' | 'crossbow' | 'chainsaw' | 'molotov';
  unlocked: boolean;
  cost: number;
  upgradeLevel: number;
}

export type ZombieType = 'shambler' | 'sprinter' | 'miner_brute' | 'bloater_spitter' | 'behemoth';

export interface Zombie {
  id: string;
  type: ZombieType;
  x: number;
  y: number;
  vx: number;
  vy: number;
  angle: number;
  speed: number;
  maxHealth: number;
  health: number;
  damage: number;
  attackCooldown: number;
  lastAttackTime: number;
  radius: number;
  color: string;
  hasHelmet?: boolean;
  isBurning?: number; // duration remaining
  burnTick?: number;
  animationFrame: number;
  scoreValue: number;
  scrapValue: number;
  spitCooldown?: number;
}

export interface Bullet {
  id: string;
  x: number;
  y: number;
  vx: number;
  vy: number;
  damage: number;
  pierce: number;
  rangeRemaining: number;
  weaponType: WeaponType;
  isMolotov?: boolean;
  isCrossbowBolt?: boolean;
  radius: number;
  color: string;
}

export interface AcidSpit {
  id: string;
  x: number;
  y: number;
  vx: number;
  vy: number;
  radius: number;
  damage: number;
  remainingDistance: number;
}

export interface FirePuddle {
  id: string;
  x: number;
  y: number;
  radius: number;
  duration: number; // in ms
  createdTime: number;
}

export interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  size: number;
  color: string;
  alpha: number;
  life: number;
  maxLife: number;
  type: 'blood' | 'smoke' | 'spark' | 'fire' | 'shell' | 'wood_splinter';
}

export interface BloodDecal {
  x: number;
  y: number;
  radius: number;
  alpha: number;
  rotation: number;
}

export type PowerupType = 'nuke' | 'insta_kill' | 'double_points' | 'infinite_ammo' | 'speed_boost';

export interface Drop {
  id: string;
  type: 'ammo_universal' | 'moonshine_med' | 'scrap' | 'molotov_pickup' | PowerupType;
  x: number;
  y: number;
  amount: number;
  duration: number;
}

export interface ActivePowerup {
  type: PowerupType;
  durationRemaining: number;
  totalDuration: number;
}

export interface ExplosiveBarrel {
  id: string;
  x: number;
  y: number;
  radius: number;
  health: number;
  maxHealth: number;
  isExploding?: boolean;
}

export interface Barricade {
  id: string;
  x: number;
  y: number;
  width: number;
  height: number;
  health: number;
  maxHealth: number;
  type: 'wood_fence' | 'sandbags' | 'coal_cart';
}

export interface MapObstacle {
  x: number;
  y: number;
  width: number;
  height: number;
  type: 'cabin' | 'pickup_truck' | 'tree' | 'rock' | 'mine_entrance' | 'crate';
  color?: string;
}

export interface PlayerStats {
  kills: number;
  headshots: number;
  shotsFired: number;
  shotsHit: number;
  damageDealt: number;
  damageTaken: number;
  scrapCollected: number;
  wavesCompleted: number;
  survivalTime: number;
}

export interface Perk {
  id: string;
  name: string;
  description: string;
  cost: number;
  level: number;
  maxLevel: number;
  icon: string;
}

export interface LoreNote {
  id: string;
  locationId: string;
  title: string;
  author: string;
  date: string;
  content: string[];
  x: number;
  y: number;
  radius: number;
  collected?: boolean;
}

export interface GameLocation {
  id: string;
  name: string;
  countyZone: string;
  description: string;
  mapWidth: number;
  mapHeight: number;
  ambientLight: number; // 0 (pitch dark) to 1 (bright)
  weather: 'fog' | 'rain' | 'night_clear';
  fogDensity: number;
  obstacles: MapObstacle[];
  barrels?: { x: number; y: number }[];
  loreNotes?: LoreNote[];
}
