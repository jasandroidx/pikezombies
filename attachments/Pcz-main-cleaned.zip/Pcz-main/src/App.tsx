import React, { useEffect, useRef, useState, useCallback } from 'react';
import { GameEngine } from './game/engine';
import { Weapon, Perk, PlayerStats, LoreNote, ActivePowerup } from './types/game';
import { INITIAL_WEAPONS, AVAILABLE_PERKS, GAME_LOCATIONS } from './game/constants';
import { soundEngine } from './audio/soundEngine';
import { HUD } from './components/HUD';
import { StartScreen } from './components/StartScreen';
import { UpgradeShopModal } from './components/UpgradeShopModal';
import { GameOverModal } from './components/GameOverModal';
import { LoreNoteModal } from './components/LoreNoteModal';
import { MobileControls } from './components/MobileControls';

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const engineRef = useRef<GameEngine | null>(null);

  // App Screen state
  const [screen, setScreen] = useState<'title' | 'playing' | 'game_over'>('title');
  const [isWorkbenchOpen, setIsWorkbenchOpen] = useState<boolean>(false);
  const [activeLoreNote, setActiveLoreNote] = useState<LoreNote | null>(null);
  const [isMuted, setIsMuted] = useState<boolean>(false);

  // Game Data
  const [selectedLocationIdx, setSelectedLocationIdx] = useState<number>(0);
  const [weapons, setWeapons] = useState<Weapon[]>(INITIAL_WEAPONS);
  const [perks, setPerks] = useState<Perk[]>(AVAILABLE_PERKS);

  // HUD Realtime Stats
  const [hudStats, setHudStats] = useState<{
    health: number;
    maxHealth: number;
    stamina: number;
    weapon: Weapon;
    molotovs: number;
    score: number;
    scrap: number;
    combo: number;
    wave: number;
    waveTimer: number;
    zombiesRemaining: number;
    isReloading: boolean;
    reloadProgress: number;
    activePowerups: ActivePowerup[];
  }>({
    health: 100,
    maxHealth: 100,
    stamina: 100,
    weapon: INITIAL_WEAPONS[0],
    molotovs: 3,
    score: 0,
    scrap: 150,
    combo: 1,
    wave: 1,
    waveTimer: 0,
    zombiesRemaining: 0,
    isReloading: false,
    reloadProgress: 0,
    activePowerups: [],
  });

  // Game Over Stats
  const [gameOverData, setGameOverData] = useState<{
    stats: PlayerStats;
    score: number;
    wave: number;
  }>({
    stats: {
      kills: 0,
      headshots: 0,
      shotsFired: 0,
      shotsHit: 0,
      damageDealt: 0,
      damageTaken: 0,
      scrapCollected: 0,
      wavesCompleted: 0,
      survivalTime: 0,
    },
    score: 0,
    wave: 1,
  });

  // Resize canvas to full window
  const updateCanvasDimensions = useCallback(() => {
    if (canvasRef.current) {
      canvasRef.current.width = window.innerWidth;
      canvasRef.current.height = window.innerHeight;
    }
  }, []);

  useEffect(() => {
    updateCanvasDimensions();
    window.addEventListener('resize', updateCanvasDimensions);
    return () => window.removeEventListener('resize', updateCanvasDimensions);
  }, [updateCanvasDimensions]);

  // Start new game
  const handleStartGame = (locationIndex: number, difficultyMultiplier: number) => {
    setSelectedLocationIdx(locationIndex);
    setScreen('playing');
    setIsWorkbenchOpen(false);

    if (!canvasRef.current) return;
    updateCanvasDimensions();

    // Destroy existing engine if any
    if (engineRef.current) {
      engineRef.current.destroy();
    }

    const newEngine = new GameEngine(
      canvasRef.current,
      {
        onWaveComplete: (completedWave) => {
          // Sync state
          if (engineRef.current) {
            setWeapons([...engineRef.current.weapons]);
            setPerks([...engineRef.current.perks]);
          }
        },
        onGameOver: (stats, finalScore) => {
          setGameOverData({
            stats,
            score: finalScore,
            wave: engineRef.current ? engineRef.current.wave : 1,
          });
          setScreen('game_over');
        },
        onStatsUpdate: (stats) => {
          setHudStats(stats);
        },
        onLoreNoteFound: (note) => {
          setActiveLoreNote(note);
          if (engineRef.current) {
            engineRef.current.setPaused(true);
          }
        },
      },
      locationIndex
    );

    engineRef.current = newEngine;
    setWeapons([...newEngine.weapons]);
    setPerks([...newEngine.perks]);
    newEngine.start(difficultyMultiplier);
  };

  // Toggle Sound
  const handleToggleMute = () => {
    const muted = soundEngine.toggleMute();
    setIsMuted(muted);
  };

  // Toggle Workbench
  const handleToggleWorkbench = () => {
    if (screen !== 'playing') return;
    setIsWorkbenchOpen((prev) => {
      const next = !prev;
      if (engineRef.current) {
        engineRef.current.setPaused(next);
      }
      return next;
    });
  };

  // Close Lore Note
  const handleCloseLoreNote = () => {
    setActiveLoreNote(null);
    if (engineRef.current && !isWorkbenchOpen) {
      engineRef.current.setPaused(false);
    }
  };

  // Global Keyboard Shortcuts (TAB / ESC for workbench, M for audio, ESC / Space for lore note)
  useEffect(() => {
    const handleKey = (e: KeyboardEvent) => {
      if (activeLoreNote) {
        if (e.code === 'Escape' || e.code === 'Space' || e.code === 'KeyE') {
          e.preventDefault();
          handleCloseLoreNote();
        }
        return;
      }

      if (e.code === 'Tab') {
        e.preventDefault();
        handleToggleWorkbench();
      } else if (e.code === 'KeyM') {
        handleToggleMute();
      } else if (e.code === 'Escape' && isWorkbenchOpen) {
        handleToggleWorkbench();
      }
    };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, [screen, isWorkbenchOpen, activeLoreNote]);

  // Workbench Actions
  const handleUnlockWeapon = (index: number) => {
    const engine = engineRef.current;
    if (!engine) return;

    const wep = engine.weapons[index];
    if (engine.scrap >= wep.cost && !wep.unlocked) {
      engine.scrap -= wep.cost;
      wep.unlocked = true;
      engine.selectWeapon(index);
      setWeapons([...engine.weapons]);
    }
  };

  const handleUpgradeWeapon = (index: number) => {
    const engine = engineRef.current;
    if (!engine) return;

    const wep = engine.weapons[index];
    const cost = Math.round(wep.damage * 4.5 * wep.upgradeLevel);
    if (engine.scrap >= cost) {
      engine.scrap -= cost;
      wep.upgradeLevel++;
      wep.damage = Math.round(wep.damage * 1.2);
      wep.magazineSize = Math.round(wep.magazineSize * 1.15);
      wep.currentMag = wep.magazineSize;
      setWeapons([...engine.weapons]);
    }
  };

  const handleUpgradePerk = (perkId: string) => {
    const engine = engineRef.current;
    if (!engine) return;

    const perk = engine.perks.find((p) => p.id === perkId);
    if (!perk) return;

    const cost = perk.cost * (perk.level + 1);
    if (engine.scrap >= cost && perk.level < perk.maxLevel) {
      engine.scrap -= cost;
      perk.level++;

      // Apply immediate perk effects
      if (perk.id === 'grit') {
        engine.player.maxHealth += 25;
        engine.player.health = Math.min(engine.player.maxHealth, engine.player.health + 25);
      }

      setPerks([...engine.perks]);
    }
  };

  const handleBuyAmmoRefill = () => {
    const engine = engineRef.current;
    if (!engine || engine.scrap < 80) return;

    engine.scrap -= 80;
    for (const w of engine.weapons) {
      if (w.unlocked) {
        w.reserveAmmo = w.maxReserveAmmo;
        w.currentMag = w.magazineSize;
      }
    }
    setWeapons([...engine.weapons]);
  };

  const handleBuyMolotov = () => {
    const engine = engineRef.current;
    if (!engine || engine.scrap < 60) return;

    if (engine.player.molotovs < engine.player.maxMolotovs) {
      engine.scrap -= 60;
      engine.player.molotovs++;
    }
  };

  // Skip wave break
  const handleSkipWaveTimer = () => {
    if (engineRef.current) {
      engineRef.current.skipWaveBreak();
    }
  };

  // Restart
  const handleRestart = () => {
    handleStartGame(selectedLocationIdx, engineRef.current ? engineRef.current.difficultyMultiplier : 1.0);
  };

  const handleHome = () => {
    if (engineRef.current) {
      engineRef.current.destroy();
      engineRef.current = null;
    }
    setScreen('title');
  };

  return (
    <main className="relative w-screen h-screen overflow-hidden bg-black select-none">
      {/* 2D Canvas */}
      <canvas
        id="game-canvas"
        ref={canvasRef}
        className="block w-full h-full cursor-crosshair"
      />

      {/* Title / Start Screen */}
      {screen === 'title' && (
        <StartScreen
          onStartGame={handleStartGame}
          isMuted={isMuted}
          onToggleMute={handleToggleMute}
        />
      )}

      {/* Active Game HUD */}
      {screen === 'playing' && (
        <>
          <HUD
            health={hudStats.health}
            maxHealth={hudStats.maxHealth}
            stamina={hudStats.stamina}
            weapon={hudStats.weapon}
            molotovs={hudStats.molotovs}
            score={hudStats.score}
            scrap={hudStats.scrap}
            combo={hudStats.combo}
            wave={hudStats.wave}
            waveTimer={hudStats.waveTimer}
            zombiesRemaining={hudStats.zombiesRemaining}
            isReloading={hudStats.isReloading}
            reloadProgress={hudStats.reloadProgress}
            isMuted={isMuted}
            activePowerups={hudStats.activePowerups}
            onToggleMute={handleToggleMute}
            onOpenWorkbench={handleToggleWorkbench}
            onSkipWaveTimer={handleSkipWaveTimer}
            locationName={GAME_LOCATIONS[selectedLocationIdx]?.name || 'Pike County'}
          />

          {/* Mobile On-Screen Controls */}
          <MobileControls
            onMoveChange={(vec) => {
              if (engineRef.current) engineRef.current.virtualJoystickMove = vec;
            }}
            onAimChange={(vec) => {
              if (engineRef.current) engineRef.current.virtualJoystickAim = vec;
            }}
            onReload={() => {
              if (engineRef.current) engineRef.current.reloadCurrentWeapon();
            }}
            onThrowMolotov={() => {
              if (engineRef.current) engineRef.current.throwMolotov();
            }}
            onPrevWeapon={() => {
              if (engineRef.current) engineRef.current.prevWeapon();
            }}
            onNextWeapon={() => {
              if (engineRef.current) engineRef.current.nextWeapon();
            }}
            onInteract={() => {
              if (engineRef.current) engineRef.current.interactLoreNote();
            }}
          />
        </>
      )}

      {/* Gunsmith & Still Workbench Modal */}
      {isWorkbenchOpen && screen === 'playing' && (
        <UpgradeShopModal
          weapons={weapons}
          perks={perks}
          scrap={hudStats.scrap}
          molotovs={hudStats.molotovs}
          maxMolotovs={5}
          onClose={handleToggleWorkbench}
          onUnlockWeapon={handleUnlockWeapon}
          onUpgradeWeapon={handleUpgradeWeapon}
          onUpgradePerk={handleUpgradePerk}
          onBuyAmmoRefill={handleBuyAmmoRefill}
          onBuyMolotov={handleBuyMolotov}
        />
      )}

      {/* Lore Note Modal */}
      {activeLoreNote && screen === 'playing' && (
        <LoreNoteModal
          note={activeLoreNote}
          onClose={handleCloseLoreNote}
        />
      )}

      {/* Game Over Modal */}
      {screen === 'game_over' && (
        <GameOverModal
          stats={gameOverData.stats}
          score={gameOverData.score}
          wave={gameOverData.wave}
          onRestart={handleRestart}
          onHome={handleHome}
        />
      )}
    </main>
  );
}
