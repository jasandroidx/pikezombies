# Pike County Zombies

Top-down Appalachian survival zombie shooter. Wave-based, canvas-rendered, built with React + TypeScript + Vite.

Originally scaffolded via Google AI Studio's app builder — the AI Studio template ships with
optional server/Gemini-API plumbing (`express`, `dotenv`, `@google/genai`) that this project
never used. That's been stripped. **This app is 100% client-side.** It does not call any
backend or AI API at runtime, despite `metadata.json` still declaring
`MAJOR_CAPABILITY_SERVER_SIDE_GEMINI_API` (leftover AI Studio platform metadata — harmless,
just inaccurate if read literally).

## Notable design choice: zero binary assets

No `.png`, `.jpg`, `.mp3`, or `.wav` files anywhere in the project.

- **Visuals** — everything is drawn with the Canvas 2D API directly (`src/game/engine.ts`
  render methods, `src/game/mapRenderer.ts`, `src/game/lighting.ts`).
- **Audio** — every gunshot, zombie groan, and ambient track is synthesized at runtime with
  the Web Audio API (`src/audio/soundEngine.ts`). No sample files loaded.

Result: the entire production build is ~350KB of JS (~104KB gzipped) and one CSS file.
No art pipeline, no asset licensing to track, loads instantly.

## Run it

```bash
npm install
npm run dev       # http://localhost:3000
npm run build     # production build to dist/
npm run preview   # serve the production build locally
npm run lint       # tsc --noEmit type check
```

Requires Node 18+. No environment variables needed — `.env.example` is an AI Studio
template artifact, not something this app currently reads.

## Architecture

```
src/
  App.tsx                 React shell — screen state (title/playing/game_over),
                           HUD data sync, keyboard shortcuts, workbench purchase handlers
  game/
    engine.ts              GameEngine class — the whole simulation: player, weapons,
                            zombies, bullets, wave manager, particles, render loop.
                            ~1,800 lines, one requestAnimationFrame loop. Organized into
                            single-purpose private methods (updatePlayer, updateBullets,
                            updateZombies, updateWaveManager, render*, etc.) but it is a
                            monolith — anything new (weapon type, zombie type, mechanic)
                            currently means editing this one file.
    constants.ts            Weapon stats, perk definitions, game locations, tuning numbers.
    mapRenderer.ts           Environment/terrain drawing.
    lighting.ts              Dynamic flashlight/lighting system.
  audio/soundEngine.ts       Procedural Web Audio synthesis, all SFX + music.
  components/                 React UI: HUD, StartScreen, UpgradeShopModal (the
                                "workbench" — gunsmith + still), GameOverModal,
                                LoreNoteModal, MobileControls (touch joystick/buttons).
  types/game.ts                Shared TS interfaces for all entity/state shapes.
```

The engine is a plain class instance held in a `useRef`, not React state — React only
re-renders on the callback ticks the engine fires (`onStatsUpdate`, `onWaveComplete`,
`onGameOver`, `onLoreNoteFound`). This keeps 60fps game state out of React's render cycle,
which is the right call for a canvas game.

## Controls

- **WASD / Arrows** — move
- **Mouse** — aim + shoot (hold to auto-fire where the weapon allows)
- **R** — reload
- **Tab / Esc** — open/close the workbench (buy weapons, upgrades, perks, ammo, molotovs)
- **M** — mute
- **Q** — throw molotov
- **1–9 / scroll** — switch weapon
- Mobile: on-screen virtual joystick + buttons (`MobileControls.tsx`)

## Known limitations (not blockers, just noted)

- `engine.ts` is a monolith. Fine at current size; if it grows much past this, split along
  its existing seams (wave/spawn manager, combat, zombie AI, renderer).
- Zombie-vs-zombie separation and bullet-vs-zombie collision are both O(n²), unbounded by
  a spatial grid. Not a real problem at current wave sizes (~10 + wave×4.5 zombies spawned
  over time); would need fixing before pushing concurrent zombie counts into the hundreds.
